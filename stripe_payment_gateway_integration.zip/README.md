# queue-test — Laravel + Stripe payments

This Laravel **11** project includes a **Stripe** integration: **Payment Intents** (Stripe.js Payment Element), optional **Stripe Checkout** (hosted page), **webhooks**, and a **`payments`** database table.

---

## Requirements

- PHP **8.2+**
- Laravel **11**
- Composer: **`stripe/stripe-php`** (^20)
- Database: MySQL (or any driver you configure)

## Quick start

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate
```

Add Stripe keys to `.env` (see below), set **`APP_URL`** to your real site URL, then open **`/payment`** in the browser.

## Environment variables

| Variable | Purpose |
|----------|---------|
| `STRIPE_KEY` | Publishable key (`pk_test_...`) — used on the checkout page in the browser. |
| `STRIPE_SECRET` | Secret key (`sk_test_...`) — server only; never expose to the frontend. |
| `STRIPE_WEBHOOK_SECRET` | Webhook signing secret (`whsec_...`) from the Dashboard or Stripe CLI. |

Values are read from **`config/services.php`** under `stripe`.

## CSRF and webhooks

`POST /stripe/webhook` is **excluded** from CSRF verification in `bootstrap/app.php` (Stripe does not send your CSRF token).  
The **`Stripe-Signature`** header is verified using **`STRIPE_WEBHOOK_SECRET`** in `StripeWebhookController`.

## Routes

| Method | Path | Route name | Description |
|--------|------|------------|-------------|
| GET | `/payment` | `payment.checkout` | Checkout UI (Payment Element + optional hosted Checkout). |
| POST | `/payment/intent` | `payment.intent` | Creates a PaymentIntent; returns `clientSecret`. |
| POST | `/payment/confirm` | `payment.confirm` | Confirms payment status on the server after the client succeeds. |
| GET | `/payment/success` | `payment.success` | Success page (`?payment_intent=pi_...`). |
| POST | `/payment/checkout-session` | `payment.checkout.session` | Creates a Stripe Checkout session; returns redirect `url`. |
| GET | `/payment/checkout/success` | `payment.checkout.success` | Return URL after hosted Checkout (`?session_id=cs_...`). |
| GET | `/payment/checkout/cancel` | `payment.checkout.cancel` | User cancelled hosted Checkout. |
| POST | `/stripe/webhook` | `stripe.webhook` | Stripe → your app (status sync). |

## Stripe-related files

| Path | Role |
|------|------|
| `app/Http/Controllers/PaymentController.php` | Intents, Checkout Session, success actions. |
| `app/Http/Controllers/StripeWebhookController.php` | Webhook verification and DB updates. |
| `app/Models/Payment.php` | Model, Stripe status mapping, `syncFromPaymentIntent()`, `formattedAmount()`. |
| `database/migrations/2026_04_21_000000_create_payments_table.php` | `payments` table. |
| `resources/views/payment/checkout.blade.php` | Checkout page. |
| `resources/views/payment-success.blade.php` | Success / thank-you page. |

## Database: `payments`

Columns include: Stripe PaymentIntent id, optional Checkout session id, amount (smallest currency unit), currency, status, optional `user_id` / `product_id`, timestamps.

## Webhooks (local)

```bash
stripe listen --forward-to http://127.0.0.1:8000/stripe/webhook
```

Put the CLI **`whsec_...`** into `STRIPE_WEBHOOK_SECRET`. Useful events: `payment_intent.succeeded`, `payment_intent.payment_failed`, `payment_intent.canceled`, `payment_intent.processing`, `checkout.session.completed`.

## Test cards

See [Stripe testing](https://stripe.com/docs/testing). Examples: **4242 4242 4242 4242** (success), **4000 0025 0000 3155** (3DS), **4000 0000 0000 0002** (decline).

## Troubleshooting

| Issue | Check |
|-------|--------|
| 503 — Stripe not configured | `STRIPE_KEY`, `STRIPE_SECRET` set; `php artisan config:clear`. |
| Wrong return URL | `APP_URL` matches how you open the app. |
| Webhook invalid signature | `STRIPE_WEBHOOK_SECRET` matches the endpoint / CLI secret. |
| Amount errors | Amounts are in the **smallest currency unit** (e.g. cents for USD). |

---

## Laravel framework

This app is built with [Laravel](https://laravel.com). Official documentation: [laravel.com/docs](https://laravel.com/docs). Laravel is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
