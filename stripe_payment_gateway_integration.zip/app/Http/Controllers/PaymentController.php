<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;
use Stripe\Checkout\Session as CheckoutSession;
use Stripe\Exception\ApiErrorException;
use Stripe\PaymentIntent;
use Stripe\Stripe;

class PaymentController extends Controller
{
    public function __construct()
    {
        $secret = config('services.stripe.secret');
        if (is_string($secret) && $secret !== '') {
            Stripe::setApiKey($secret);
        }
    }

    public function checkout(Request $request): View
    {
        $this->ensureStripeConfigured();

        return view('payment.checkout', [
            'stripeKey' => config('services.stripe.key'),
            'defaultAmountDollars' => old('amount_dollars', $request->input('amount_dollars', '9.99')),
            'defaultCurrency' => strtolower(old('currency', $request->string('currency', 'usd')->toString())),
            'defaultProductId' => old('product_id', $request->input('product_id')),
        ]);
    }

    public function createPaymentIntent(Request $request): JsonResponse
    {
        $this->ensureStripeConfigured();

        $validated = $request->validate([
            'amount' => ['required', 'integer', 'min:50'],
            'currency' => ['required', 'string', 'size:3', 'regex:/^[a-z]{3}$/'],
            'product_id' => ['nullable', 'integer', 'min:1'],
        ]);

        $userId = Auth::id();

        try {
            $intent = PaymentIntent::create([
                'amount' => $validated['amount'],
                'currency' => $validated['currency'],
                'automatic_payment_methods' => ['enabled' => true],
                'metadata' => [
                    'user_id' => $userId !== null ? (string) $userId : '',
                    'product_id' => isset($validated['product_id']) ? (string) $validated['product_id'] : '',
                ],
            ]);

            Payment::syncFromPaymentIntent(
                $intent,
                $userId,
                $validated['product_id'] ?? null,
            );
        } catch (ApiErrorException $e) {
            return response()->json([
                'message' => 'Unable to start payment. Please try again.',
                'error' => config('app.debug') ? $e->getMessage() : null,
            ], 422);
        }

        return response()->json([
            'clientSecret' => $intent->client_secret,
            'paymentIntentId' => $intent->id,
        ]);
    }

    public function confirmPayment(Request $request): JsonResponse
    {
        $this->ensureStripeConfigured();

        $validated = $request->validate([
            'payment_intent_id' => ['required', 'string', 'regex:/^pi_[a-zA-Z0-9]+$/'],
        ]);

        try {
            $intent = PaymentIntent::retrieve($validated['payment_intent_id']);
        } catch (ApiErrorException $e) {
            return response()->json([
                'message' => 'Payment could not be verified.',
                'error' => config('app.debug') ? $e->getMessage() : null,
            ], 422);
        }

        if ($intent->status !== PaymentIntent::STATUS_SUCCEEDED) {
            return response()->json([
                'message' => 'Payment is not completed yet. Status: '.$intent->status,
            ], 422);
        }

        Payment::syncFromPaymentIntent($intent);

        return response()->json([
            'ok' => true,
            'redirect_url' => route('payment.success', ['payment_intent' => $intent->id]),
        ]);
    }

    public function success(Request $request): View|RedirectResponse
    {
        $this->ensureStripeConfigured();

        $validated = $request->validate([
            'payment_intent' => ['required', 'string', 'regex:/^pi_[a-zA-Z0-9]+$/'],
        ]);

        try {
            $intent = PaymentIntent::retrieve($validated['payment_intent']);
        } catch (ApiErrorException $e) {
            return redirect()
                ->route('payment.checkout')
                ->with('error', 'Could not load payment details. '.$e->getMessage());
        }

        if ($intent->status !== PaymentIntent::STATUS_SUCCEEDED) {
            return redirect()
                ->route('payment.checkout')
                ->with('error', 'This payment is not successful yet.');
        }

        $payment = Payment::syncFromPaymentIntent($intent);

        return view('payment-success', $this->paymentSuccessViewData($payment));
    }

    public function createCheckoutSession(Request $request): JsonResponse
    {
        $this->ensureStripeConfigured();

        $validated = $request->validate([
            'amount' => ['required', 'integer', 'min:50'],
            'currency' => ['required', 'string', 'size:3', 'regex:/^[a-z]{3}$/'],
            'product_id' => ['nullable', 'integer', 'min:1'],
            'product_name' => ['nullable', 'string', 'max:120'],
        ]);

        $userId = Auth::id();

        try {
            $session = CheckoutSession::create([
                'mode' => 'payment',
                'success_url' => route('payment.checkout.success').'?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => route('payment.checkout.cancel'),
                'client_reference_id' => $userId !== null ? (string) $userId : null,
                'line_items' => [
                    [
                        'price_data' => [
                            'currency' => $validated['currency'],
                            'unit_amount' => $validated['amount'],
                            'product_data' => [
                                'name' => $validated['product_name'] ?? 'Order',
                            ],
                        ],
                        'quantity' => 1,
                    ],
                ],
                'metadata' => [
                    'user_id' => $userId !== null ? (string) $userId : '',
                    'product_id' => isset($validated['product_id']) ? (string) $validated['product_id'] : '',
                ],
            ]);
        } catch (ApiErrorException $e) {
            return response()->json([
                'message' => 'Unable to start Checkout session.',
                'error' => config('app.debug') ? $e->getMessage() : null,
            ], 422);
        }

        return response()->json(['url' => $session->url]);
    }

    public function checkoutSuccess(Request $request): View|RedirectResponse
    {
        $this->ensureStripeConfigured();

        $validated = $request->validate([
            'session_id' => ['required', 'string', 'regex:/^cs_[a-zA-Z0-9]+$/'],
        ]);

        try {
            $session = CheckoutSession::retrieve($validated['session_id']);
        } catch (ApiErrorException $e) {
            return redirect()
                ->route('payment.checkout')
                ->with('error', 'Invalid checkout session.');
        }

        $rawPi = $session->payment_intent ?? null;
        $piId = match (true) {
            is_string($rawPi) => $rawPi,
            is_object($rawPi) && isset($rawPi->id) => (string) $rawPi->id,
            default => null,
        };
        if ($piId === null || ! str_starts_with($piId, 'pi_')) {
            return redirect()
                ->route('payment.checkout')
                ->with('error', 'No payment was completed for this session.');
        }

        try {
            $intent = PaymentIntent::retrieve($piId);
        } catch (ApiErrorException $e) {
            return redirect()
                ->route('payment.checkout')
                ->with('error', 'Could not verify payment.');
        }

        $payment = Payment::syncFromPaymentIntent($intent);
        $payment->forceFill(['stripe_checkout_session_id' => $session->id])->save();

        if ($intent->status !== PaymentIntent::STATUS_SUCCEEDED) {
            return redirect()
                ->route('payment.checkout')
                ->with('error', 'Payment status: '.$intent->status);
        }

        return view('payment-success', $this->paymentSuccessViewData($payment));
    }

    public function checkoutCancel(): RedirectResponse
    {
        return redirect()
            ->route('payment.checkout')
            ->with('error', 'Checkout was cancelled.');
    }

    /**
     * @return array{amount: string, transaction_id: string, date: string, website_url: string, redirect_url: string, redirect_seconds: int}
     */
    private function paymentSuccessViewData(Payment $payment): array
    {
        $timestamp = $payment->updated_at ?? now();

        return [
            'amount' => $payment->formattedAmount(),
            'transaction_id' => $payment->stripe_payment_intent_id ?? '—',
            'date' => $timestamp->timezone(config('app.timezone'))->format('M j, Y \a\t g:i A'),
            'website_url' => url('/'),
            'redirect_url' => url('/'),
            'redirect_seconds' => 5,
        ];
    }

    private function ensureStripeConfigured(): void
    {
        $key = config('services.stripe.key');
        $secret = config('services.stripe.secret');
        if (! is_string($key) || $key === '' || ! is_string($secret) || $secret === '') {
            abort(503, 'Stripe is not configured. Add STRIPE_KEY and STRIPE_SECRET to your .env file.');
        }
    }
}
