<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use Stripe\Exception\SignatureVerificationException;
use Stripe\Stripe;
use Stripe\Webhook;
use UnexpectedValueException;

class StripeWebhookController extends Controller
{
    public function __invoke(Request $request): Response
    {
        $secret = config('services.stripe.webhook_secret');
        if (! is_string($secret) || $secret === '') {
            Log::error('Stripe webhook secret is not configured.');

            return response('Webhook not configured', 500);
        }

        Stripe::setApiKey(config('services.stripe.secret'));

        $payload = $request->getContent();
        $sigHeader = $request->header('Stripe-Signature');

        try {
            $event = Webhook::constructEvent($payload, $sigHeader, $secret);
        } catch (UnexpectedValueException) {
            return response('Invalid payload', 400);
        } catch (SignatureVerificationException) {
            return response('Invalid signature', 400);
        }

        try {
            match ($event->type) {
                'payment_intent.succeeded',
                'payment_intent.payment_failed',
                'payment_intent.canceled',
                'payment_intent.processing' => $this->handlePaymentIntentEvent($event->data->object),
                'checkout.session.completed' => $this->handleCheckoutSessionCompleted($event->data->object),
                default => null,
            };
        } catch (\Throwable $e) {
            Log::error('Stripe webhook handler error', [
                'type' => $event->type,
                'message' => $e->getMessage(),
            ]);

            return response('Handler error', 500);
        }

        return response('OK', 200);
    }

    private function handlePaymentIntentEvent(object $intent): void
    {
        if (! isset($intent->id) || ! str_starts_with((string) $intent->id, 'pi_')) {
            return;
        }

        $stripeIntent = \Stripe\PaymentIntent::retrieve($intent->id);
        Payment::syncFromPaymentIntent($stripeIntent);
    }

    private function handleCheckoutSessionCompleted(object $session): void
    {
        $raw = $session->payment_intent ?? null;
        $piId = match (true) {
            is_string($raw) => $raw,
            is_object($raw) && isset($raw->id) => (string) $raw->id,
            default => null,
        };
        if ($piId === null || ! str_starts_with($piId, 'pi_')) {
            return;
        }

        $stripeIntent = \Stripe\PaymentIntent::retrieve($piId);
        $payment = Payment::syncFromPaymentIntent($stripeIntent);

        if (isset($session->id) && is_string($session->id)) {
            $payment->forceFill(['stripe_checkout_session_id' => $session->id])->save();
        }
    }
}
