<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Stripe\PaymentIntent;

class Payment extends Model
{
    public const STATUS_PENDING = 'pending';

    public const STATUS_REQUIRES_ACTION = 'requires_action';

    public const STATUS_PROCESSING = 'processing';

    public const STATUS_SUCCEEDED = 'succeeded';

    public const STATUS_FAILED = 'failed';

    public const STATUS_CANCELED = 'canceled';

    protected $fillable = [
        'stripe_payment_intent_id',
        'stripe_checkout_session_id',
        'amount',
        'currency',
        'status',
        'user_id',
        'product_id',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Human-readable amount using Stripe’s smallest-currency rules.
     *
     * @see https://stripe.com/docs/currencies#zero-decimal
     */
    public function formattedAmount(): string
    {
        $zeroDecimal = ['bif', 'clp', 'djf', 'gnf', 'jpy', 'kmf', 'krw', 'mga', 'pyg', 'rwf', 'ugx', 'vnd', 'vuv', 'xaf', 'xof', 'xpf'];
        $cur = strtolower($this->currency);
        if (in_array($cur, $zeroDecimal, true)) {
            return number_format($this->amount, 0).' '.strtoupper($this->currency);
        }

        return number_format($this->amount / 100, 2).' '.strtoupper($this->currency);
    }

    public static function mapStripeIntentStatus(string $stripeStatus): string
    {
        return match ($stripeStatus) {
            PaymentIntent::STATUS_REQUIRES_PAYMENT_METHOD,
            PaymentIntent::STATUS_REQUIRES_CONFIRMATION => self::STATUS_PENDING,
            PaymentIntent::STATUS_REQUIRES_ACTION => self::STATUS_REQUIRES_ACTION,
            PaymentIntent::STATUS_REQUIRES_CAPTURE, PaymentIntent::STATUS_PROCESSING => self::STATUS_PROCESSING,
            PaymentIntent::STATUS_SUCCEEDED => self::STATUS_SUCCEEDED,
            PaymentIntent::STATUS_CANCELED => self::STATUS_CANCELED,
            default => self::STATUS_FAILED,
        };
    }

    public static function syncFromPaymentIntent(
        PaymentIntent $intent,
        ?int $userId = null,
        ?int $productId = null,
    ): self {
        $metaUser = $intent->metadata['user_id'] ?? null;
        $metaProduct = $intent->metadata['product_id'] ?? null;

        return self::updateOrCreate(
            ['stripe_payment_intent_id' => $intent->id],
            [
                'amount' => $intent->amount,
                'currency' => $intent->currency,
                'status' => self::mapStripeIntentStatus($intent->status),
                'user_id' => $userId ?? (is_numeric($metaUser) ? (int) $metaUser : null),
                'product_id' => $productId ?? (is_numeric($metaProduct) ? (int) $metaProduct : null),
            ],
        );
    }
}
