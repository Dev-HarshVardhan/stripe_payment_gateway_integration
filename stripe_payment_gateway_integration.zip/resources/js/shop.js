import * as bootstrap from "bootstrap";
import "../css/shop.css";

window.bootstrap = bootstrap;

(function () {
  "use strict";

  function applyStoredTheme() {
    const stored = localStorage.getItem("shop-theme");
    if (stored === "dark") {
      document.documentElement.setAttribute("data-bs-theme", "dark");
    }
  }

  function initThemeToggle() {
    const btn = document.getElementById("shopThemeToggle");
    if (!btn) return;
    btn.addEventListener("click", () => {
      const next = document.documentElement.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-bs-theme", next);
      localStorage.setItem("shop-theme", next);
      btn.setAttribute("aria-label", next === "dark" ? "Switch to light mode" : "Switch to dark mode");
    });
  }

  function initFlashCountdown() {
    const el = document.getElementById("shopFlashCountdown");
    if (!el) return;
    const end = parseInt(el.getAttribute("data-end"), 10);
    if (!end) return;
    function tick() {
      const now = Date.now();
      const left = Math.max(0, Math.floor((end - now) / 1000));
      const h = Math.floor(left / 3600);
      const m = Math.floor((left % 3600) / 60);
      const s = left % 60;
      el.textContent =
        (h > 0 ? String(h).padStart(2, "0") + ":" : "") +
        String(m).padStart(2, "0") +
        ":" +
        String(s).padStart(2, "0");
      if (left <= 0) clearInterval(timer);
    }
    tick();
    const timer = setInterval(tick, 1000);
  }

  function initPlistToggle() {
    const gridBtn = document.getElementById("qcViewGrid");
    const listBtn = document.getElementById("qcViewList");
    const container = document.getElementById("qcProductGrid");
    if (!gridBtn || !listBtn || !container) return;
    gridBtn.addEventListener("click", () => {
      container.classList.remove("qc-plist-mode");
      gridBtn.classList.add("active");
      listBtn.classList.remove("active");
    });
    listBtn.addEventListener("click", () => {
      container.classList.add("qc-plist-mode");
      listBtn.classList.add("active");
      gridBtn.classList.remove("active");
    });
    if (listBtn.classList.contains("active")) container.classList.add("qc-plist-mode");
  }

  function initPdpThumbs() {
    const main = document.getElementById("qcPdpMainImg");
    const thumbs = document.querySelectorAll("[data-qc-pdp-thumb]");
    if (!main || !thumbs.length) return;
    thumbs.forEach((t) => {
      t.addEventListener("click", () => {
        const src = t.getAttribute("data-src");
        if (src) main.setAttribute("src", src);
        thumbs.forEach((x) => {
          x.classList.toggle("active", x === t);
        });
      });
    });
  }

  function initCheckoutToast() {
    const el = document.getElementById("shopCheckoutToast");
    if (!el || !window.bootstrap?.Toast) return;
    new window.bootstrap.Toast(el, { delay: 4000 }).show();
  }

  function initAuthOtpTimer() {
    const el = document.getElementById("otpTimer");
    const otpCollapse = document.getElementById("otpSection");
    if (!el || !otpCollapse) return;
    otpCollapse.addEventListener("shown.bs.collapse", () => {
      let t = 30;
      const id = setInterval(() => {
        t--;
        el.textContent = "00:" + String(Math.max(0, t)).padStart(2, "0");
        if (t <= 0) clearInterval(id);
      }, 1000);
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    applyStoredTheme();
    initThemeToggle();
    initFlashCountdown();
    initPlistToggle();
    initPdpThumbs();
    initCheckoutToast();
    initAuthOtpTimer();
  });
})();
