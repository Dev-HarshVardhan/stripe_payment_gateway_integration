<?php

use App\Http\Controllers\StorefrontController;
use Illuminate\Support\Facades\Route;  
  use App\Http\Controllers\PostController;
use App\Http\Controllers\FeedController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PaymentController;

Route::get('/', function () {
    return view('welcome');
});

Route::prefix('shop')
    ->name('shop.')
    ->group(function () {
        Route::get('/', [StorefrontController::class, 'index'])->name('home');
        Route::get('/category', [StorefrontController::class, 'category'])->name('category');
        Route::get('/product', [StorefrontController::class, 'product'])->name('product');
        Route::get('/cart', [StorefrontController::class, 'cart'])->name('cart');
        Route::get('/checkout', [StorefrontController::class, 'checkout'])->name('checkout');
        Route::get('/login', [StorefrontController::class, 'login'])->name('login');
        Route::get('/account', [StorefrontController::class, 'account'])->name('account');
        Route::get('/search', [StorefrontController::class, 'search'])->name('search');
        Route::get('/order', [StorefrontController::class, 'tracking'])->name('order');
        Route::get('/orders/track', [StorefrontController::class, 'tracking'])->name('orders.track');
    });





Route::get('/feed', [FeedController::class, 'index']); 
Route::get('/create-post', [PostController::class, 'create']); 
Route::post('/store-post', [PostController::class, 'store']);  
 
 
Route::get('/users', [UserController::class, 'index']); 
Route::get('/users/create', function () { 
    return view('users.create'); 
}); 

Route::post('/users', [UserController::class, 'store']);
Route::post('/users/update/{id}', [UserController::class, 'update']);
Route::get('/users/delete/{id}', [UserController::class, 'destroy']);

Route::prefix('payment')->name('payment.')->group(function () {
    Route::get('/', [PaymentController::class, 'checkout'])->name('checkout');
    Route::post('/intent', [PaymentController::class, 'createPaymentIntent'])->name('intent');
    Route::post('/confirm', [PaymentController::class, 'confirmPayment'])->name('confirm');
    Route::get('/success', [PaymentController::class, 'success'])->name('success');
    Route::post('/checkout-session', [PaymentController::class, 'createCheckoutSession'])->name('checkout.session');
    Route::get('/checkout/success', [PaymentController::class, 'checkoutSuccess'])->name('checkout.success');
    Route::get('/checkout/cancel', [PaymentController::class, 'checkoutCancel'])->name('checkout.cancel');
});

Route::post('/stripe/webhook', \App\Http\Controllers\StripeWebhookController::class)->name('stripe.webhook');