

<?php $__env->startSection('title', 'Search'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('store.partials.header-search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_class', 'container py-3 pb-5'); ?>

<?php $__env->startSection('content'); ?>
    <p class="small text-shop-muted mb-4">Results for <span class="text-body fw-medium">“organic milk”</span></p>

    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-3 mb-5">
        <div class="col">
            <article class="qc-card-product d-flex flex-column h-100">
                <div class="position-relative">
                    <a href="<?php echo e(route('shop.product')); ?>" class="d-block text-decoration-none">
                        <div class="qc-img-wrap"><img src="https://picsum.photos/seed/s1/400/400" alt="" loading="lazy"></div>
                    </a>
                    <button type="button" class="shop-wishlist" aria-label="Wishlist"><i class="bi bi-heart"></i></button>
                </div>
                <div class="card-body p-3 d-flex flex-column flex-grow-1">
                    <div class="small text-truncate text-shop-faint mb-1">DailyDairy</div>
                    <a href="<?php echo e(route('shop.product')); ?>" class="fw-semibold text-body text-truncate mb-1 text-decoration-none" style="font-size: 0.9rem">Organic <mark class="px-0 border-0 bg-transparent text-decoration-underline" style="color: var(--shop-primary)">milk</mark> 1L</a>
                    <div class="mt-auto d-flex justify-content-between align-items-end pt-2">
                        <div class="qc-price-current">₹56</div>
                        <button type="button" class="btn btn-shop-primary btn-icon-add rounded-3"><i class="bi bi-plus-lg"></i></button>
                    </div>
                </div>
            </article>
        </div>
        <div class="col">
            <article class="qc-card-product d-flex flex-column h-100">
                <div class="position-relative">
                    <a href="<?php echo e(route('shop.product')); ?>" class="d-block text-decoration-none">
                        <div class="qc-img-wrap"><img src="https://picsum.photos/seed/s2/400/400" alt="" loading="lazy"></div>
                    </a>
                    <button type="button" class="shop-wishlist" aria-label="Wishlist"><i class="bi bi-heart"></i></button>
                </div>
                <div class="card-body p-3 d-flex flex-column flex-grow-1">
                    <div class="small text-truncate text-shop-faint mb-1">DailyDairy</div>
                    <a href="<?php echo e(route('shop.product')); ?>" class="fw-semibold text-body text-truncate mb-1 text-decoration-none" style="font-size: 0.9rem">Full cream milk</a>
                    <div class="mt-auto d-flex justify-content-between align-items-end pt-2">
                        <div class="qc-price-current">₹62</div>
                        <button type="button" class="btn btn-shop-primary btn-icon-add rounded-3"><i class="bi bi-plus-lg"></i></button>
                    </div>
                </div>
            </article>
        </div>
    </div>

    <h2 class="shop-section-title h6 mb-3">Trending now</h2>
    <div class="row row-cols-2 row-cols-md-4 g-3">
        <?php $__currentLoopData = ['fl1', 'fl2', 'fl3', 'fl4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $seed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <a href="<?php echo e(route('shop.product')); ?>" class="text-decoration-none text-body">
                    <div class="rounded-4 overflow-hidden border mb-2" style="border-color: var(--shop-border) !important">
                        <img src="https://picsum.photos/seed/<?php echo e($seed); ?>/400/400" class="w-100 object-fit-cover" alt="" style="aspect-ratio: 1">
                    </div>
                    <div class="small fw-medium text-truncate">Pick <?php echo e($i + 1); ?></div>
                    <div class="qc-price-current small">₹<?php echo e(29 + $i * 11); ?></div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\search.blade.php ENDPATH**/ ?>