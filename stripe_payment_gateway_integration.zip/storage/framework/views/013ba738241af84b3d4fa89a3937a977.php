

<?php $__env->startSection('title', 'Account'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('store.partials.header-profile', ['navActive' => $navActive], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card border-0 rounded-4 mb-4 overflow-hidden" style="box-shadow: var(--shop-shadow)">
        <div class="card-body d-flex flex-wrap align-items-center gap-4 p-4">
            <div class="rounded-circle d-flex align-items-center justify-content-center text-white shop-display fw-semibold" style="width: 72px; height: 72px; background: linear-gradient(145deg, var(--shop-primary), var(--shop-primary-hover)); font-size: 1.5rem">AK</div>
            <div class="flex-grow-1 min-w-0">
                <h1 class="h5 shop-section-title mb-1">Alex Kumar</h1>
                <p class="small text-shop-muted mb-0">+91 98765 43210 · alex@email.com</p>
                <span class="badge rounded-pill mt-2 fw-normal border-0" style="background: var(--shop-accent-soft); color: var(--shop-accent)">Member</span>
            </div>
            <button type="button" class="btn btn-sm rounded-pill border-0 bg-body-secondary px-3">Edit</button>
        </div>
    </div>

    <ul class="nav nav-pills mb-4 flex-nowrap gap-2 overflow-auto pb-1" role="tablist" style="scrollbar-width: thin">
        <li class="nav-item" role="presentation">
            <button class="nav-link shop-nav-pill active rounded-pill border-0" id="orders-tab" data-bs-toggle="pill" data-bs-target="#orders-panel" type="button" role="tab">Orders</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link shop-nav-pill rounded-pill border-0 bg-body-secondary text-body" id="addr-tab" data-bs-toggle="pill" data-bs-target="#addr-panel" type="button" role="tab">Addresses</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link shop-nav-pill rounded-pill border-0 bg-body-secondary text-body" id="wish-tab" data-bs-toggle="pill" data-bs-target="#wish-panel" type="button" role="tab">Wishlist</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link shop-nav-pill rounded-pill border-0 bg-body-secondary text-body" id="settings-tab" data-bs-toggle="pill" data-bs-target="#settings-panel" type="button" role="tab">Settings</button>
        </li>
    </ul>

    <div class="tab-content">
        <div class="tab-pane fade show active" id="orders-panel" role="tabpanel" aria-labelledby="orders-tab" tabindex="0">
            <div class="position-relative ps-3">
                <div class="position-absolute top-0 bottom-0 start-0 border-start" style="border-color: var(--shop-border) !important; left: 6px"></div>
                <div class="d-flex flex-column gap-3">
                    <a href="<?php echo e(route('shop.order')); ?>" class="text-decoration-none">
                        <div class="card border-0 rounded-4 p-3 ms-3 position-relative" style="box-shadow: var(--shop-shadow)">
                            <span class="position-absolute top-0 start-0 translate-middle-x rounded-circle bg-body border" style="width: 12px; height: 12px; left: -1.35rem; top: 1.25rem; border-color: var(--shop-primary) !important; background: var(--shop-primary) !important"></span>
                            <div class="d-flex gap-3">
                                <img src="https://picsum.photos/seed/o1/64/64" width="52" height="52" class="rounded-3 object-fit-cover" alt="">
                                <div class="flex-grow-1 min-w-0">
                                    <div class="d-flex justify-content-between align-items-start gap-2 mb-1">
                                        <span class="fw-semibold text-body">#QM-9021</span>
                                        <span class="badge rounded-pill border-0 fw-medium" style="background: var(--shop-primary-soft); color: var(--shop-primary)">On the way</span>
                                    </div>
                                    <p class="small text-shop-muted mb-0">3 items · ₹428</p>
                                    <p class="small text-shop-faint mb-0 mt-1"><?php echo e(now()->format('M j · g:i A')); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="<?php echo e(route('shop.order')); ?>" class="text-decoration-none">
                        <div class="card border-0 rounded-4 p-3 ms-3 position-relative" style="box-shadow: var(--shop-shadow)">
                            <span class="position-absolute top-0 start-0 translate-middle-x rounded-circle border bg-body-secondary" style="width: 12px; height: 12px; left: -1.35rem; top: 1.25rem"></span>
                            <div class="d-flex gap-3">
                                <img src="https://picsum.photos/seed/o2/64/64" width="52" height="52" class="rounded-3 object-fit-cover" alt="">
                                <div class="flex-grow-1 min-w-0">
                                    <div class="d-flex justify-content-between align-items-start gap-2 mb-1">
                                        <span class="fw-semibold text-body">#QM-8890</span>
                                        <span class="badge rounded-pill bg-body-secondary text-shop-muted border-0">Delivered</span>
                                    </div>
                                    <p class="small text-shop-muted mb-0">5 items · ₹612</p>
                                    <p class="small text-shop-faint mb-0 mt-1">Apr 10 · 6:02 PM</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <div class="tab-pane fade" id="addr-panel" role="tabpanel" aria-labelledby="addr-tab" tabindex="0">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h6 shop-section-title mb-0">Saved addresses</h2>
                <button type="button" class="btn btn-link btn-sm p-0 fw-medium" style="color: var(--shop-primary)">+ Add</button>
            </div>
            <div class="d-flex flex-column gap-3">
                <div class="card border-0 rounded-4 p-4" style="box-shadow: var(--shop-shadow)">
                    <div class="d-flex justify-content-between align-items-start gap-2">
                        <div>
                            <div class="fw-semibold">Home</div>
                            <p class="small text-shop-muted mb-0 mt-1">12th Main, Indiranagar, Bengaluru — 560038</p>
                            <span class="badge rounded-pill mt-2 bg-body-secondary text-shop-muted fw-normal">Default</span>
                        </div>
                        <button type="button" class="btn btn-sm rounded-pill border-0 bg-body-secondary">Edit</button>
                    </div>
                </div>
                <div class="card border-0 rounded-4 p-4" style="box-shadow: var(--shop-shadow)">
                    <div class="d-flex justify-content-between align-items-start gap-2">
                        <div>
                            <div class="fw-semibold">Office</div>
                            <p class="small text-shop-muted mb-0 mt-1">100 Feet Road, Bengaluru — 560071</p>
                        </div>
                        <button type="button" class="btn btn-sm rounded-pill border-0 bg-body-secondary">Edit</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-pane fade" id="wish-panel" role="tabpanel" aria-labelledby="wish-tab" tabindex="0">
            <div class="row row-cols-2 row-cols-md-3 g-3">
                <?php $__currentLoopData = ['Dark chocolate' => 'w1', 'Sparkling water' => 'w2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $seed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <article class="qc-card-product d-flex flex-column h-100">
                            <div class="position-relative">
                                <div class="qc-img-wrap"><img src="https://picsum.photos/seed/<?php echo e($seed); ?>/400/400" alt=""></div>
                                <button type="button" class="shop-wishlist" aria-label="Remove"><i class="bi bi-heart-fill" style="color: var(--shop-danger)"></i></button>
                            </div>
                            <div class="card-body p-3">
                                <div class="fw-semibold text-body text-truncate small"><?php echo e($label); ?></div>
                                <div class="qc-price-current">₹<?php echo e($loop->first ? '89' : '40'); ?></div>
                                <button type="button" class="btn btn-shop-primary btn-sm w-100 mt-2 rounded-pill">Add to bag</button>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="tab-pane fade" id="settings-panel" role="tabpanel" aria-labelledby="settings-tab" tabindex="0">
            <div class="card border-0 rounded-4 overflow-hidden" style="box-shadow: var(--shop-shadow)">
                <a href="#" class="list-group-item list-group-item-action border-0 py-3 px-4 d-flex justify-content-between align-items-center text-decoration-none text-body">
                    <span><i class="bi bi-bell me-3 text-shop-muted"></i>Notifications</span>
                    <i class="bi bi-chevron-right text-shop-faint"></i>
                </a>
                <a href="#" class="list-group-item list-group-item-action border-0 py-3 px-4 d-flex justify-content-between align-items-center text-decoration-none text-body">
                    <span><i class="bi bi-credit-card me-3 text-shop-muted"></i>Payment methods</span>
                    <i class="bi bi-chevron-right text-shop-faint"></i>
                </a>
                <a href="#" class="list-group-item list-group-item-action border-0 py-3 px-4 d-flex justify-content-between align-items-center text-decoration-none text-body">
                    <span><i class="bi bi-shield-check me-3 text-shop-muted"></i>Privacy</span>
                    <i class="bi bi-chevron-right text-shop-faint"></i>
                </a>
                <a href="#" class="list-group-item list-group-item-action border-0 py-3 px-4 d-flex justify-content-between align-items-center text-decoration-none text-body">
                    <span><i class="bi bi-question-circle me-3 text-shop-muted"></i>Help centre</span>
                    <i class="bi bi-chevron-right text-shop-faint"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="text-center mt-5">
        <a href="<?php echo e(route('shop.login')); ?>" class="btn btn-link text-shop-muted btn-sm">Sign out</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\profile.blade.php ENDPATH**/ ?>