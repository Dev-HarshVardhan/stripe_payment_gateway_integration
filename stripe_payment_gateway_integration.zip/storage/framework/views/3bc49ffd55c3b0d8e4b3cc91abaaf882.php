<!DOCTYPE html>
<html>
<head>
    <title>Create User</title>

    <style>
        body {
            font-family: Arial;
            background: #f4f6f9;
        }

        .box {
            width: 400px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        input, textarea {
            width: 100%;
            padding: 8px;
            margin-top: 10px;
        }

        button {
            margin-top: 10px;
            background: green;
            color: white;
            padding: 10px;
            width: 100%;
            border: none;
            cursor: pointer;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>

<body>

<div class="box">
<?php if(session('success')): ?>
    <div class="alert alert-success" style="color:green;">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

    <h2>Create User</h2>

    <form action="/users" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
 
        <input type="text" name="name" placeholder="Enter Name" required>

        <input type="email" name="email" placeholder="Enter Email" required>

        <input type="password" name="password" placeholder="Enter Password" required>

        <textarea name="address" placeholder="Enter Address"></textarea>

        <input type="file" name="image">

        <button type="submit">Save User</button>
    </form>

    <a href="/users">Back to List</a>

</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\users\create.blade.php ENDPATH**/ ?>