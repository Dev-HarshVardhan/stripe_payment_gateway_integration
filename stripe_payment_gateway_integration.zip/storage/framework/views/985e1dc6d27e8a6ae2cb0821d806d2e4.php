<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Payment successful</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card border-success shadow-sm">
                <div class="card-body p-4 text-center">
                    <h1 class="h4 text-success mb-3">Payment successful</h1>
                    <p class="text-muted mb-4">Your transaction was recorded. Webhooks will keep the status in sync with Stripe.</p>
                    <dl class="row text-start small mb-0">
                        <dt class="col-sm-5">Stripe PaymentIntent</dt>
                        <dd class="col-sm-7"><code><?php echo e($payment->stripe_payment_intent_id); ?></code></dd>
                        <dt class="col-sm-5">Amount</dt>
                        <dd class="col-sm-7"><?php echo e($payment->formattedAmount()); ?></dd>
                        <dt class="col-sm-5">Status</dt>
                        <dd class="col-sm-7"><span class="badge text-bg-success"><?php echo e($payment->status); ?></span></dd>
                        <?php if($payment->user_id): ?>
                            <dt class="col-sm-5">User ID</dt>
                            <dd class="col-sm-7"><?php echo e($payment->user_id); ?></dd>
                        <?php endif; ?>
                        <?php if($payment->product_id): ?>
                            <dt class="col-sm-5">Product ID</dt>
                            <dd class="col-sm-7"><?php echo e($payment->product_id); ?></dd>
                        <?php endif; ?>
                    </dl>
                    <a href="<?php echo e(route('payment.checkout')); ?>" class="btn btn-outline-primary mt-4">Pay again</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\payment\success.blade.php ENDPATH**/ ?>