

<?php $__env->startSection('title', 'Your cart'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('store.partials.header-minimal', ['title' => 'Cart', 'backUrl' => route('shop.home')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_class', 'container py-3 pb-5'); ?>

<?php $__env->startSection('content'); ?>
    <div class="qc-progress-wrap mb-3">
        <div class="d-flex justify-content-between small mb-1">
            <span>Add <strong>₹72</strong> more for free delivery</span>
            <span class="text-qc-tertiary">₹428 / ₹500</span>
        </div>
        <div class="progress"><div class="progress-bar bg-success" style="width: 86%"></div></div>
    </div>

    <ul class="list-group list-group-flush border rounded-3 mb-3 shadow-sm">
        <?php $__currentLoopData = [['cart1', 'Organic Toned Milk 1L', '56 × 2', '2', '112'], ['cart2', 'Masala chips 150g', '40 × 1', '1', '40'], ['cart3', 'Bananas Robusta', '42 × 2', '2', '84']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item py-3">
                <div class="row g-2 align-items-center">
                    <div class="col-auto">
                        <img src="https://picsum.photos/seed/<?php echo e($line[0]); ?>/80/80" width="72" height="72" class="rounded-2" alt="">
                    </div>
                    <div class="col">
                        <a href="<?php echo e(route('shop.product')); ?>" class="fw-semibold text-body text-decoration-none"><?php echo e($line[1]); ?></a>
                        <div class="small text-qc-secondary">₹<?php echo e($line[2]); ?></div>
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div class="input-group input-group-sm" style="width: 120px">
                                <button class="btn btn-outline-secondary" type="button">−</button>
                                <input type="number" class="form-control text-center" value="<?php echo e($line[3]); ?>" readonly>
                                <button class="btn btn-outline-secondary" type="button">+</button>
                            </div>
                            <button type="button" class="btn btn-link text-danger btn-sm p-0">Remove</button>
                        </div>
                    </div>
                    <div class="col-auto text-end">
                        <div class="qc-price-current">₹<?php echo e($line[4]); ?></div>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body">
            <label class="form-label fw-semibold small">Have a coupon?</label>
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Enter code">
                <button class="btn btn-shop-outline rounded-pill" type="button">Apply</button>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-5">
        <div class="card-body">
            <h2 class="h6 shop-section-title mb-3">Bill details</h2>
            <div class="d-flex justify-content-between small mb-2">
                <span class="text-qc-secondary">Item total (MRP)</span>
                <span>₹482</span>
            </div>
            <div class="d-flex justify-content-between small mb-2 text-success">
                <span>Product discount</span>
                <span>− ₹54</span>
            </div>
            <div class="d-flex justify-content-between small mb-2">
                <span class="text-qc-secondary">Delivery fee</span>
                <span>₹0</span>
            </div>
            <div class="d-flex justify-content-between small mb-2">
                <span class="text-qc-secondary">Handling</span>
                <span>₹0</span>
            </div>
            <hr>
            <div class="d-flex justify-content-between align-items-center">
                <span class="fw-bold">To pay</span>
                <span class="qc-price-current" style="font-size: 1.25rem">₹428</span>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('fab'); ?>
    <div class="qc-sticky-bar">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center gap-3">
                <div>
                    <div class="small text-qc-secondary">3 items</div>
                    <div class="qc-price-current">₹428</div>
                </div>
                <a href="<?php echo e(route('shop.checkout')); ?>" class="btn btn-shop-primary btn-lg flex-grow-1 text-decoration-none rounded-pill py-3" style="max-width: 320px">Checkout</a>
            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\cart.blade.php ENDPATH**/ ?>