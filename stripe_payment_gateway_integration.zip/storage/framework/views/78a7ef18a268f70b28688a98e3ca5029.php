<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> — Shop</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/shop.js']); ?>
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="shop-body qc-body <?php echo $__env->yieldContent('body_class'); ?>">
    <?php echo $__env->yieldContent('header'); ?>
    <main class="<?php echo $__env->yieldContent('main_class', 'container py-3'); ?>">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->yieldPushContent('fab'); ?>
    <?php if (! (isset($hideFooter) && $hideFooter)): ?>
        <?php echo $__env->make('store.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\layouts\storefront.blade.php ENDPATH**/ ?>