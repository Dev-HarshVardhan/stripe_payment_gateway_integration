<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Payment Successful</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --success-1: #0d9488;
            --success-2: #34d399;
            --success-3: #6ee7b7;
            --ink: #0f172a;
            --muted: #64748b;
            --card: rgba(255, 255, 255, 0.92);
            --shadow: 0 25px 50px -12px rgba(13, 148, 136, 0.25);
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
            color: var(--ink);
            overflow-x: hidden;
        }

        .bg-stage {
            position: fixed;
            inset: 0;
            z-index: 0;
            background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 35%, #a7f3d0 70%, #6ee7b7 100%);
            background-size: 400% 400%;
            animation: gradientShift 12s ease infinite;
        }

        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.45;
            animation: floatBlob 18s ease-in-out infinite;
        }

        .blob-1 {
            width: 320px;
            height: 320px;
            background: #34d399;
            top: -80px;
            right: -60px;
            animation-delay: 0s;
        }

        .blob-2 {
            width: 280px;
            height: 280px;
            background: #2dd4bf;
            bottom: 10%;
            left: -80px;
            animation-delay: -6s;
        }

        .blob-3 {
            width: 200px;
            height: 200px;
            background: #6ee7b7;
            bottom: -40px;
            right: 20%;
            animation-delay: -12s;
        }

        @keyframes floatBlob {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -20px) scale(1.05); }
            66% { transform: translate(-20px, 15px) scale(0.95); }
        }

        /* Shimmer loading layer */
        .shimmer-layer {
            position: fixed;
            inset: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(90deg, #ecfdf5 0%, #d1fae5 50%, #ecfdf5 100%);
            background-size: 200% 100%;
            animation: shimmerMove 1.2s ease-in-out infinite;
            transition: opacity 0.5s ease, visibility 0.5s ease;
        }

        .shimmer-layer.done {
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
        }

        @keyframes shimmerMove {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }

        .shimmer-card {
            width: min(90%, 360px);
            height: 120px;
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.5);
            position: relative;
            overflow: hidden;
        }

        .shimmer-card::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(
                90deg,
                transparent,
                rgba(255, 255, 255, 0.85),
                transparent
            );
            animation: shimmerCard 1.5s ease-in-out infinite;
        }

        @keyframes shimmerCard {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .wrap {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .card {
            width: 100%;
            max-width: 440px;
            background: var(--card);
            backdrop-filter: blur(12px);
            border-radius: 24px;
            padding: 40px 32px 36px;
            box-shadow: var(--shadow);
            border: 1px solid rgba(255, 255, 255, 0.8);
            text-align: center;
            opacity: 0;
            transform: scale(0.92) translateY(16px);
            transition: opacity 0.65s cubic-bezier(0.22, 1, 0.36, 1),
                        transform 0.65s cubic-bezier(0.22, 1, 0.36, 1);
        }

        .card.reveal {
            opacity: 1;
            transform: scale(1) translateY(0);
        }

        .icon-wrap {
            width: 96px;
            height: 96px;
            margin: 0 auto 24px;
            position: relative;
        }

        .icon-ring {
            position: absolute;
            inset: 0;
            border-radius: 50%;
            background: linear-gradient(145deg, var(--success-2), var(--success-1));
            opacity: 0.2;
            animation: ringPulse 2s ease-out infinite;
        }

        @keyframes ringPulse {
            0% { transform: scale(0.85); opacity: 0.35; }
            100% { transform: scale(1.35); opacity: 0; }
        }

        .check-svg {
            width: 96px;
            height: 96px;
            display: block;
        }

        .check-circle {
            fill: none;
            stroke: url(#successGrad);
            stroke-width: 3;
            stroke-linecap: round;
            stroke-dasharray: 166;
            stroke-dashoffset: 166;
            transform-origin: 50% 50%;
            animation: drawCircle 0.7s ease forwards 0.15s;
        }

        .check-path {
            fill: none;
            stroke: url(#successGrad);
            stroke-width: 3;
            stroke-linecap: round;
            stroke-linejoin: round;
            stroke-dasharray: 48;
            stroke-dashoffset: 48;
            animation: drawCheck 0.45s ease forwards 0.65s;
        }

        @keyframes drawCircle {
            to { stroke-dashoffset: 0; }
        }

        @keyframes drawCheck {
            to { stroke-dashoffset: 0; }
        }

        h1 {
            margin: 0 0 12px;
            font-size: clamp(1.5rem, 4vw, 1.75rem);
            font-weight: 700;
            letter-spacing: -0.02em;
            color: var(--ink);
            opacity: 0;
            animation: fadeUp 0.55s ease forwards 0.5s;
        }

        .sub {
            margin: 0 0 28px;
            font-size: 0.95rem;
            line-height: 1.55;
            color: var(--muted);
            opacity: 0;
            animation: fadeUp 0.55s ease forwards 0.62s;
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(8px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .details {
            text-align: left;
            background: linear-gradient(180deg, rgba(236, 253, 245, 0.9) 0%, rgba(209, 250, 229, 0.5) 100%);
            border-radius: 16px;
            padding: 20px 20px 18px;
            margin-bottom: 28px;
            border: 1px solid rgba(52, 211, 153, 0.25);
            opacity: 0;
            animation: fadeUp 0.55s ease forwards 0.74s;
        }

        .row-d {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            padding: 10px 0;
            border-bottom: 1px solid rgba(100, 116, 139, 0.12);
            font-size: 0.875rem;
        }

        .row-d:last-child {
            border-bottom: 0;
            padding-bottom: 0;
        }

        .row-d dt {
            margin: 0;
            font-weight: 500;
            color: var(--muted);
            flex-shrink: 0;
        }

        .row-d dd {
            margin: 0;
            font-weight: 600;
            color: var(--ink);
            text-align: right;
            word-break: break-all;
        }

        .amount-highlight {
            font-size: 1.125rem;
            color: var(--success-1);
        }

        .btn-primary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            padding: 14px 24px;
            font-family: inherit;
            font-size: 0.95rem;
            font-weight: 600;
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 14px;
            cursor: pointer;
            background: linear-gradient(135deg, var(--success-1), #059669);
            box-shadow: 0 10px 25px -8px rgba(13, 148, 136, 0.55);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            opacity: 0;
            animation: fadeUp 0.55s ease forwards 0.86s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 14px 30px -8px rgba(13, 148, 136, 0.6);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        .redirect-hint {
            margin-top: 16px;
            font-size: 0.8rem;
            color: var(--muted);
            opacity: 0;
            animation: fadeUp 0.55s ease forwards 0.95s;
        }

        .redirect-hint span {
            font-weight: 600;
            color: var(--success-1);
        }

        @media (prefers-reduced-motion: reduce) {
            .bg-stage,
            .blob,
            .shimmer-layer,
            .shimmer-card::after,
            .icon-ring,
            .check-circle,
            .check-path,
            h1, .sub, .details, .btn-primary, .redirect-hint {
                animation: none !important;
            }

            .shimmer-layer {
                transition: none;
            }

            .shimmer-layer.done {
                display: none;
            }

            .card {
                opacity: 1;
                transform: none;
            }

            .check-circle {
                stroke-dashoffset: 0;
            }

            .check-path {
                stroke-dashoffset: 0;
            }

            h1, .sub, .details, .btn-primary, .redirect-hint {
                opacity: 1;
                transform: none;
            }
        }
    </style>
</head>
<body>
    <div class="bg-stage" aria-hidden="true"></div>
    <div class="blob blob-1" aria-hidden="true"></div>
    <div class="blob blob-2" aria-hidden="true"></div>
    <div class="blob blob-3" aria-hidden="true"></div>

    <div class="shimmer-layer" id="shimmer" role="status" aria-live="polite" aria-label="Loading">
        <div class="shimmer-card"></div>
    </div>

    <div class="wrap">
        <article class="card" id="success-card">
            <div class="icon-wrap" aria-hidden="true">
                <div class="icon-ring"></div>
                <svg class="check-svg" viewBox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="successGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style="stop-color:#34d399"/>
                            <stop offset="100%" style="stop-color:#0d9488"/>
                        </linearGradient>
                    </defs>
                    <circle class="check-circle" cx="48" cy="48" r="26"/>
                    <path class="check-path" d="M34 48 L44 58 L62 38"/>
                </svg>
            </div>

            <h1>Payment Successful</h1>
            <p class="sub">Your payment has been processed successfully.</p>

            <dl class="details">
                <div class="row-d">
                    <dt>Amount paid</dt>
                    <dd class="amount-highlight"><?php echo e($amount); ?></dd>
                </div>
                <div class="row-d">
                    <dt>Transaction ID</dt>
                    <dd><?php echo e($transaction_id); ?></dd>
                </div>
                <div class="row-d">
                    <dt>Date &amp; time</dt>
                    <dd><?php echo e($date); ?></dd>
                </div>
            </dl>

            <a href="<?php echo e($website_url); ?>" class="btn-primary" id="btn-website">Go to Website</a>
            <p class="redirect-hint" id="redirect-hint">
                Redirecting in <span id="countdown"><?php echo e($redirect_seconds); ?></span>s…
            </p>
        </article>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>
    <script>
        (function () {
            const shimmer = document.getElementById('shimmer');
            const card = document.getElementById('success-card');
            const countdownEl = document.getElementById('countdown');
            const redirectHint = document.getElementById('redirect-hint');
            const redirectUrl = <?php echo json_encode($redirect_url, 15, 512) ?>;
            const totalSeconds = <?php echo e((int) $redirect_seconds); ?>;

            const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

            function burstConfetti() {
                if (prefersReduced || typeof confetti !== 'function') return;
                const count = 160;
                const defaults = { origin: { y: 0.65 }, zIndex: 200 };

                function fire(particleRatio, opts) {
                    confetti({
                        ...defaults,
                        ...opts,
                        particleCount: Math.floor(count * particleRatio),
                    });
                }

                fire(0.25, { spread: 26, startVelocity: 35 });
                fire(0.2, { spread: 60 });
                fire(0.35, { spread: 100, decay: 0.91, scalar: 0.85 });
                fire(0.1, { spread: 120, startVelocity: 25, decay: 0.92, scalar: 1.1 });
                fire(0.1, { spread: 120, startVelocity: 45 });
            }

            function startExperience() {
                shimmer.classList.add('done');
                card.classList.add('reveal');
                setTimeout(burstConfetti, prefersReduced ? 0 : 950);
            }

            if (prefersReduced) {
                shimmer.classList.add('done');
                card.classList.add('reveal');
            } else {
                setTimeout(startExperience, 900);
            }

            if (totalSeconds <= 0) {
                redirectHint.style.display = 'none';
                return;
            }

            let left = totalSeconds;
            const timer = setInterval(function () {
                left -= 1;
                if (countdownEl) countdownEl.textContent = String(Math.max(left, 0));
                if (left <= 0) {
                    clearInterval(timer);
                    window.location.href = redirectUrl;
                }
            }, 1000);
        })();
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views/payment-success.blade.php ENDPATH**/ ?>