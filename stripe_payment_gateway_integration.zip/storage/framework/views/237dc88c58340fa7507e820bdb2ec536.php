<?php
    $s = $idSuffix ?? '';
?>
<div class="mb-4">
    <h3 class="h6 fw-semibold mb-3" style="font-size: 0.8rem; letter-spacing: 0.04em; text-transform: uppercase; color: var(--shop-muted)">Price</h3>
    <label for="qcPriceRange<?php echo e($s); ?>" class="form-label small text-shop-muted">₹0 — ₹500</label>
    <input type="range" class="form-range" id="qcPriceRange<?php echo e($s); ?>" min="0" max="500" value="250">
    <div class="row g-2">
        <div class="col-6">
            <input type="number" class="form-control form-control-sm border-0 bg-body-secondary" placeholder="Min" value="0">
        </div>
        <div class="col-6">
            <input type="number" class="form-control form-control-sm border-0 bg-body-secondary" placeholder="Max" value="500">
        </div>
    </div>
</div>
<div class="mb-4">
    <h3 class="h6 fw-semibold mb-3" style="font-size: 0.8rem; letter-spacing: 0.04em; text-transform: uppercase; color: var(--shop-muted)">Rating</h3>
    <div class="d-flex flex-wrap gap-2">
        <input type="radio" class="btn-check" name="rating<?php echo e($s); ?>" id="r4<?php echo e($s); ?>" autocomplete="off" checked>
        <label class="btn btn-outline-secondary btn-sm rounded-pill border-0 bg-body-secondary" for="r4<?php echo e($s); ?>"><i class="bi bi-star-fill" style="color: #e8b923"></i> 4+</label>
        <input type="radio" class="btn-check" name="rating<?php echo e($s); ?>" id="r3<?php echo e($s); ?>" autocomplete="off">
        <label class="btn btn-outline-secondary btn-sm rounded-pill border-0 bg-body-secondary" for="r3<?php echo e($s); ?>">3+</label>
    </div>
</div>
<div class="mb-0">
    <h3 class="h6 fw-semibold mb-3" style="font-size: 0.8rem; letter-spacing: 0.04em; text-transform: uppercase; color: var(--shop-muted)">Brand</h3>
    <input type="search" class="form-control form-control-sm border-0 bg-body-secondary mb-2" placeholder="Search brands">
    <div class="d-flex flex-column gap-2 small">
        <label class="d-flex gap-2 align-items-center"><input class="form-check-input" type="checkbox" checked> CrunchCo</label>
        <label class="d-flex gap-2 align-items-center"><input class="form-check-input" type="checkbox"> PureJuice</label>
        <label class="d-flex gap-2 align-items-center"><input class="form-check-input" type="checkbox"> FizzUp</label>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\partials\filter-panel.blade.php ENDPATH**/ ?>