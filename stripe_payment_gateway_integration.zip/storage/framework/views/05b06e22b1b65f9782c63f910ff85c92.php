<!DOCTYPE html>
<html>
<head>
    <title>Users Dashboard</title>

    <style>
        body {
            font-family: Arial;
            background: #f4f6f9;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
        }

        h2 {
            text-align: center;
        }

        .btn {
            background: green;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 5px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        img {
            border-radius: 50%;
        }

        .delete {
            background: red;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
        }

        .edit {
            background: orange;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
        }

    </style>
</head>

<body>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="container">

    <h2>Users List</h2>

    <a class="btn" href="/users/create">+ Add User</a>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Image</th>
            <th>Address</th>
            <th>Action</th>
        </tr>

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>

            <td>
                <?php if($user->image): ?>
                    <img src="/uploads/<?php echo e($user->image); ?>" width="50" height="50">
                <?php else: ?>
                    N/A
                <?php endif; ?>
            </td>

            <td><?php echo e($user->address); ?></td>

            <td>
                <a class="delete" href="/users/delete/<?php echo e($user->id); ?>">Delete</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\users\index.blade.php ENDPATH**/ ?>