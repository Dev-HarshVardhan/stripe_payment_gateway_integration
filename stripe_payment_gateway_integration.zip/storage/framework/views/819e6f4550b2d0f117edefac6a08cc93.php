

<?php $__env->startSection('title', 'Groceries, delivered fast'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('store.partials.header-home', ['navActive' => $navActive], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="shop-hero-ref position-relative rounded-4 overflow-hidden mb-4 border bg-white" style="border-color: var(--shop-border) !important">
        <div class="ratio ratio-21x9 bg-body-secondary">
            <img src="https://picsum.photos/seed/yosemite/1600/640" class="object-fit-cover w-100 h-100" alt="">
        </div>
        <div class="shop-hero-overlay position-absolute bottom-0 start-0 end-0 d-flex flex-wrap justify-content-between align-items-end gap-3 p-3 p-md-4">
            <div class="pe-2">
                <p class="shop-hero-kicker mb-1">Fresh today</p>
                <p class="shop-hero-title text-white mb-0 fw-semibold">Seasonal produce &amp; daily essentials</p>
            </div>
            <span class="badge rounded-pill px-3 py-2 fw-semibold border-0 shop-hero-cta">~12 min</span>
        </div>
    </div>

    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="shop-section-title h5 mb-0">Categories</h2>
            <a href="<?php echo e(route('shop.category')); ?>" class="small fw-medium text-decoration-none" style="color: var(--shop-primary)">See all</a>
        </div>
        <div class="row row-cols-4 g-3 text-center">
            <?php $__currentLoopData = ['Fruits' => 'apple', 'Dairy' => 'cup-straw', 'Snacks' => 'basket2', 'Drinks' => 'droplet', 'Breakfast' => 'egg-fried', 'Health' => 'heart-pulse', 'Home' => 'house', 'More' => 'grid']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <a href="<?php echo e(route('shop.category')); ?>" class="text-decoration-none d-block shop-cat-cell">
                        <div class="shop-cat-circle mx-auto d-flex align-items-center justify-content-center mb-2">
                            <i class="bi bi-<?php echo e($icon); ?> shop-cat-circle-icon"></i>
                        </div>
                        <span class="small fw-medium text-body"><?php echo e($label); ?></span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="shop-section-title h5 mb-0">Trending</h2>
            <a href="<?php echo e(route('shop.category')); ?>" class="small fw-medium text-decoration-none" style="color: var(--shop-primary)">View</a>
        </div>
        <div class="row row-cols-2 row-cols-md-4 g-3">
            <?php
                $featured = [
                    ['f1', 'Farmfresh', 'Bananas, Robusta', '42', '52', '10% OFF', '4.6', '1.2k'],
                    ['f2', 'DailyDairy', 'Fresh Milk 1L', '56', '60', '10% OFF', '4.8', '890'],
                    ['f3', 'CrunchCo', 'Salted Chips 150g', '35', '40', '10% OFF', '4.3', '340'],
                    ['f4', 'PureJuice', 'Orange 1L', '99', '110', '10% OFF', '4.5', '210'],
                ];
            ?>
            <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <article class="qc-card-product d-flex flex-column h-100 shop-ref-card">
                        <div class="qc-img-wrap">
                            <a href="<?php echo e(route('shop.product')); ?>" class="d-block h-100 text-decoration-none">
                                <img src="https://picsum.photos/seed/<?php echo e($row[0]); ?>/400/400" alt="" loading="lazy">
                            </a>
                            <?php if(! empty($row[5])): ?>
                                <span class="position-absolute top-0 start-0 m-2 qc-badge-discount shop-ref-discount"><?php echo e($row[5]); ?></span>
                            <?php endif; ?>
                            <button type="button" class="shop-wishlist border-0" aria-label="Wishlist"><i class="bi bi-heart"></i></button>
                            <button type="button" class="shop-quick-add btn d-inline-flex align-items-center justify-content-center" aria-label="Add">
                                <i class="bi bi-plus-lg text-white"></i>
                            </button>
                        </div>
                        <div class="card-body p-3 pt-2 d-flex flex-column flex-grow-1">
                            <div class="small text-uppercase text-shop-faint mb-1" style="font-size: 0.68rem; letter-spacing: 0.04em"><?php echo e($row[1]); ?></div>
                            <a href="<?php echo e(route('shop.product')); ?>" class="fw-semibold text-body text-truncate mb-1 text-decoration-none" style="font-size: 0.92rem"><?php echo e($row[2]); ?></a>
                            <div class="qc-rating mb-2"><i class="bi bi-star-fill"></i> <?php echo e($row[6]); ?></div>
                            <div class="d-flex align-items-baseline gap-2 mt-auto">
                                <span class="qc-price-current mb-0">₹<?php echo e($row[3]); ?></span>
                                <span class="qc-price-mrp mb-0">₹<?php echo e($row[4]); ?></span>
                            </div>
                        </div>
                    </article>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <section class="mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
            <h2 class="shop-section-title h5 mb-0">Flash deals</h2>
            <div class="d-flex align-items-center gap-2">
                <span class="small text-shop-muted">Ends in</span>
                <span class="shop-countdown" id="shopFlashCountdown" data-end="<?php echo e($flashEndsAt); ?>"></span>
            </div>
        </div>
        <div class="qc-shelf">
            <?php $__currentLoopData = ['Energy bar' => ['fl1', '25'], 'Sparkling water' => ['fl2', '40'], 'Dark chocolate' => ['fl3', '89']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="width: 156px">
                    <article class="qc-card-product d-flex flex-column h-100 shop-ref-card">
                        <div class="qc-img-wrap position-relative">
                            <img src="https://picsum.photos/seed/<?php echo e($data[0]); ?>/400/400" alt="" loading="lazy">
                            <span class="position-absolute top-0 start-0 m-2 qc-badge-discount shop-ref-discount">10% OFF</span>
                            <button type="button" class="shop-wishlist border-0" aria-label="Wishlist"><i class="bi bi-heart"></i></button>
                            <button type="button" class="shop-quick-add btn d-inline-flex align-items-center justify-content-center" aria-label="Add"><i class="bi bi-plus-lg text-white"></i></button>
                        </div>
                        <div class="card-body p-2 pt-2">
                            <div class="small fw-semibold text-truncate"><?php echo e($label); ?></div>
                            <div class="qc-price-current small">₹<?php echo e($data[1]); ?></div>
                            <button type="button" class="btn btn-shop-primary btn-sm w-100 mt-2 fw-semibold shop-ref-add-full">Add</button>
                        </div>
                    </article>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('fab'); ?>
    <a href="<?php echo e(route('shop.cart')); ?>" class="btn btn-shop-primary shop-fab d-inline-flex d-md-none align-items-center gap-2 text-decoration-none shadow rounded-pill">
        <i class="bi bi-bag fs-5"></i>
        <span class="fw-semibold">₹428</span>
        <span class="badge rounded-pill bg-white text-dark border" style="font-size: 0.7rem">3</span>
    </a>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\home.blade.php ENDPATH**/ ?>