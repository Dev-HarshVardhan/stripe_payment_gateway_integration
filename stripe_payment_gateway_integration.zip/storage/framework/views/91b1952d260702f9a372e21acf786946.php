

<?php $__env->startSection('title', 'Track order'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('store.partials.header-minimal', ['title' => 'Track order', 'backUrl' => route('shop.account')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_class', 'container py-3 pb-5'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-0">
            <div class="ratio ratio-21x9 bg-body-secondary rounded-top">
                <img src="https://picsum.photos/seed/map1/1200/400" class="object-fit-cover rounded-top" alt="" style="opacity: 0.85">
                <div class="position-absolute bottom-0 start-0 end-0 p-3 bg-dark bg-gradient bg-opacity-75 text-white">
                    <div class="small opacity-75">Rider is nearby</div>
                    <div class="fw-semibold">Arriving in ~6 min</div>
                </div>
            </div>
            <div class="p-3 border-top">
                <div class="d-flex justify-content-between align-items-start gap-2">
                    <div>
                        <div class="text-qc-tertiary small">Order #QM-9021</div>
                        <div class="fw-semibold">3 items · ₹428</div>
                    </div>
                    <span class="badge bg-success-subtle text-success">On the way</span>
                </div>
            </div>
        </div>
    </div>

    <section class="mb-4">
        <h2 class="h6 shop-section-title mb-3">Delivery progress</h2>
        <div class="progress mb-4" style="height: 10px; border-radius: 999px">
            <div class="progress-bar bg-success" style="width: 75%"></div>
        </div>

        <div class="qc-timeline">
            <div class="qc-timeline-item done">
                <div class="qc-timeline-dot"><i class="bi bi-check-lg"></i></div>
                <div class="fw-semibold">Order placed</div>
                <div class="small text-qc-secondary"><?php echo e(now()->format('M j, g:i A')); ?></div>
            </div>
            <div class="qc-timeline-item done">
                <div class="qc-timeline-dot"><i class="bi bi-check-lg"></i></div>
                <div class="fw-semibold">Packed</div>
                <div class="small text-qc-secondary">Recently</div>
            </div>
            <div class="qc-timeline-item active">
                <div class="qc-timeline-dot"><i class="bi bi-truck"></i></div>
                <div class="fw-semibold">On the way</div>
                <div class="small text-qc-secondary">Rider: Ravi · Vehicle DL 4W XX 0000</div>
            </div>
            <div class="qc-timeline-item">
                <div class="qc-timeline-dot"></div>
                <div class="fw-semibold text-qc-secondary">Delivered</div>
                <div class="small text-qc-tertiary">Estimated soon</div>
            </div>
        </div>
    </section>

    <div class="d-grid gap-2 d-sm-flex">
        <button type="button" class="btn btn-shop-outline flex-fill rounded-pill"><i class="bi bi-chat-dots me-2"></i>Chat</button>
        <button type="button" class="btn btn-shop-outline flex-fill rounded-pill"><i class="bi bi-telephone me-2"></i>Call</button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront', ['hideFooter' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\tracking.blade.php ENDPATH**/ ?>