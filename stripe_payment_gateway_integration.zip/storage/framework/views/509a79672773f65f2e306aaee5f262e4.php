<?php
    $backUrl = $backUrl ?? route('shop.home');
?>
<header class="shop-shell sticky-top shop-glass border-bottom">
    <div class="container py-3 d-flex align-items-center gap-2">
        <a class="btn btn-link text-shop-muted px-0 rounded-circle" href="<?php echo e($backUrl); ?>" aria-label="Back"><i class="bi bi-arrow-left fs-5"></i></a>
        <span class="shop-display fw-semibold mb-0 flex-grow-1" style="font-size: 1.05rem"><?php echo e($title ?? ''); ?></span>
        <button type="button" class="btn btn-link p-2 rounded-circle text-shop-muted ms-auto" id="shopThemeToggle" aria-label="Toggle dark mode">
            <i class="bi bi-moon-stars fs-5"></i>
        </button>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\partials\header-minimal.blade.php ENDPATH**/ ?>