

<?php $__env->startSection('title', 'Organic Toned Milk 1L'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('store.partials.header-product', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_class', 'container py-3 pb-5'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row g-4">
        <div class="col-lg-6">
            <div class="position-relative rounded-3 overflow-hidden qc-pdp-main-img mb-3">
                <img id="qcPdpMainImg" src="https://picsum.photos/seed/pdp1/800/800" class="w-100" alt="Organic Toned Milk 1L" style="aspect-ratio: 1; object-fit: cover">
                <span class="position-absolute top-0 start-0 m-3 badge bg-danger">12% OFF</span>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <img class="qc-thumb active" src="https://picsum.photos/seed/pdp1/200/200" alt="" width="64" height="64" data-qc-pdp-thumb data-src="https://picsum.photos/seed/pdp1/800/800">
                <img class="qc-thumb" src="https://picsum.photos/seed/pdp2/200/200" alt="" width="64" height="64" data-qc-pdp-thumb data-src="https://picsum.photos/seed/pdp2/800/800">
                <img class="qc-thumb" src="https://picsum.photos/seed/pdp3/200/200" alt="" width="64" height="64" data-qc-pdp-thumb data-src="https://picsum.photos/seed/pdp3/800/800">
            </div>
        </div>
        <div class="col-lg-6">
            <p class="small text-qc-secondary mb-1">DailyDairy</p>
            <h1 class="qc-section-title h3 mb-2">Organic Toned Milk 1L</h1>
            <div class="d-flex align-items-center gap-2 mb-3">
                <span class="qc-rating"><i class="bi bi-star-fill"></i> 4.8</span>
                <span class="text-qc-tertiary small">(890 ratings)</span>
                <span class="badge text-bg-light border">Verified buyers</span>
            </div>
            <div class="d-flex align-items-baseline gap-2 mb-1">
                <span class="qc-price-current" style="font-size: 1.5rem">₹56</span>
                <span class="qc-price-mrp">₹64</span>
                <span class="qc-badge-discount">Save ₹8</span>
            </div>
            <p class="small text-success mb-4"><i class="bi bi-lightning-charge-fill"></i> Delivery in ~12 min to Indiranagar</p>

            <div class="d-flex align-items-center gap-3 mb-4">
                <span class="small fw-semibold text-qc-secondary">Qty</span>
                <div class="input-group" style="max-width: 140px">
                    <button class="btn btn-outline-secondary" type="button" aria-label="Decrease">−</button>
                    <input type="number" class="form-control text-center" value="1" min="1" max="6">
                    <button class="btn btn-outline-secondary" type="button" aria-label="Increase">+</button>
                </div>
                <span class="small text-qc-tertiary">Max 6 per order</span>
            </div>

            <div class="d-grid gap-2 d-md-flex mb-4">
                <button type="button" class="btn btn-shop-primary btn-lg flex-fill rounded-pill"><i class="bi bi-bag-plus me-2"></i>Add to bag</button>
                <button type="button" class="btn btn-shop-outline btn-lg flex-fill rounded-pill">Buy now</button>
            </div>

            <div class="accordion" id="pdpAccordion">
                <div class="accordion-item border-0 border-top rounded-0">
                    <h2 class="accordion-header">
                        <button class="accordion-button px-0" type="button" data-bs-toggle="collapse" data-bs-target="#descCollapse">Description</button>
                    </h2>
                    <div id="descCollapse" class="accordion-collapse collapse show" data-bs-parent="#pdpAccordion">
                        <div class="accordion-body px-0 text-qc-secondary small pt-0">
                            Pasteurised toned milk sourced from partner farms. Store refrigerated at 4°C. Best before date printed on pack.
                        </div>
                    </div>
                </div>
                <div class="accordion-item border-0 border-top rounded-0">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed px-0" type="button" data-bs-toggle="collapse" data-bs-target="#nutriCollapse">Nutrition &amp; ingredients</button>
                    </h2>
                    <div id="nutriCollapse" class="accordion-collapse collapse" data-bs-parent="#pdpAccordion">
                        <div class="accordion-body px-0 text-qc-secondary small pt-0">Energy, protein, and ingredient list placeholder for layout.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="mt-5">
        <h2 class="qc-section-title h5 mb-3">Ratings &amp; reviews</h2>
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="p-3 rounded-3 border bg-body-secondary bg-opacity-10">
                    <div class="display-6 fw-bold qc-display">4.8</div>
                    <div class="text-warning mb-2">
                        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i>
                    </div>
                    <p class="small text-qc-secondary mb-0">Based on 890 reviews</p>
                </div>
            </div>
            <div class="col-md-8">
                <div class="d-flex align-items-center gap-2 mb-1 small">
                    <span style="width: 3rem">5★</span>
                    <div class="progress flex-grow-1 qc-progress-wrap"><div class="progress-bar bg-success" style="width: 72%"></div></div>
                    <span class="text-qc-tertiary">72%</span>
                </div>
                <div class="d-flex align-items-center gap-2 mb-1 small">
                    <span style="width: 3rem">4★</span>
                    <div class="progress flex-grow-1"><div class="progress-bar bg-success" style="width: 18%"></div></div>
                    <span class="text-qc-tertiary">18%</span>
                </div>
                <div class="d-flex align-items-center gap-2 small">
                    <span style="width: 3rem">3★</span>
                    <div class="progress flex-grow-1"><div class="progress-bar bg-success" style="width: 7%"></div></div>
                    <span class="text-qc-tertiary">7%</span>
                </div>
            </div>
        </div>
        <div class="card border-0 shadow-sm mb-2">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                        <strong class="small">Priya S.</strong>
                        <span class="badge bg-success-subtle text-success ms-2 small">Verified</span>
                    </div>
                    <span class="text-qc-tertiary small">2 days ago</span>
                </div>
                <div class="text-warning small mb-2">
                    <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                </div>
                <p class="mb-0 small text-qc-secondary">Fresh every time — packaging could be better.</p>
            </div>
        </div>
        <button type="button" class="btn btn-link text-success px-0">Read all reviews</button>
    </section>

    <section class="mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="qc-section-title h5 mb-0">Related products</h2>
            <a href="<?php echo e(route('shop.category')); ?>" class="small fw-semibold text-success text-decoration-none">See category</a>
        </div>
        <div class="qc-shelf">
            <?php $__currentLoopData = ['Full cream 1L' => 'rel1', 'Curd 400g' => 'rel2', 'Butter 100g' => 'rel3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $seed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="width: 160px">
                    <article class="qc-card-product d-flex flex-column h-100">
                        <div class="qc-img-wrap"><img src="https://picsum.photos/seed/<?php echo e($seed); ?>/400/400" alt=""></div>
                        <div class="card-body p-2">
                            <div class="small fw-semibold text-truncate"><?php echo e($label); ?></div>
                            <div class="qc-price-current small">₹<?php echo e($loop->iteration === 1 ? '62' : ($loop->iteration === 2 ? '45' : '55')); ?></div>
                            <a href="<?php echo e(route('shop.product')); ?>" class="btn btn-shop-primary btn-sm w-100 mt-2 rounded-pill">View</a>
                        </div>
                    </article>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <div class="qc-sticky-bar d-lg-none">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center gap-2">
                <div>
                    <div class="small text-qc-secondary">Total</div>
                    <div class="qc-price-current">₹56</div>
                </div>
                <button type="button" class="btn btn-shop-primary flex-grow-1 rounded-pill py-2" style="max-width: 240px">Add to bag</button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\product.blade.php ENDPATH**/ ?>