

<?php $__env->startSection('title', 'Sign in'); ?>

<?php $__env->startSection('body_class', 'd-flex flex-column min-vh-100'); ?>

<?php $__env->startSection('header'); ?>
    <header class="shop-glass border-bottom py-3">
        <div class="container d-flex align-items-center">
            <a class="btn btn-link text-shop-muted px-0 rounded-circle" href="<?php echo e(route('shop.home')); ?>" aria-label="Back"><i class="bi bi-arrow-left fs-5"></i></a>
            <span class="ms-2 shop-display fw-semibold">Sign in</span>
            <button type="button" class="btn btn-link p-2 rounded-circle text-shop-muted ms-auto" id="shopThemeToggle" aria-label="Toggle dark mode">
                <i class="bi bi-moon-stars fs-5"></i>
            </button>
        </div>
    </header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_class', 'container flex-grow-1 d-flex align-items-center py-5'); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-100 mx-auto" style="max-width: 400px">
        <div class="text-center mb-4">
            <div class="shop-display fw-semibold mb-2" style="font-size: 1.35rem; letter-spacing: -0.04em">Shop</div>
            <p class="text-shop-muted small mb-0">We’ll text you a one-time code</p>
        </div>

        <div class="card border-0 rounded-4 p-4 p-md-5" style="box-shadow: var(--shop-shadow)">
            <label class="form-label small text-shop-muted fw-medium" for="phone">Mobile number</label>
            <div class="input-group input-group-lg mb-4">
                <span class="input-group-text border-0 bg-body-secondary rounded-start-4">+91</span>
                <input type="tel" class="form-control border-0 bg-body-secondary rounded-end-4" id="phone" placeholder="98765 43210" maxlength="10" inputmode="numeric">
            </div>
            <button type="button" class="btn btn-shop-primary w-100 rounded-pill py-3 fw-semibold" data-bs-toggle="collapse" data-bs-target="#otpSection">Continue</button>
        </div>

        <div class="collapse mt-4" id="otpSection">
            <div class="card border-0 rounded-4 p-4 p-md-5" style="box-shadow: var(--shop-shadow)">
                <p class="small text-shop-muted mb-3">Code sent to <strong>+91 98765 43210</strong> · <a href="#" class="text-decoration-none fw-medium" style="color: var(--shop-primary)">Edit</a></p>
                <label class="form-label small fw-medium text-shop-muted">Enter code</label>
                <div class="qc-otp-group d-flex gap-2 justify-content-between mb-3" role="group" aria-label="OTP">
                    <?php for($i = 1; $i <= 6; $i++): ?>
                        <input type="text" class="form-control border-0 bg-body-secondary" maxlength="1" inputmode="numeric" aria-label="Digit <?php echo e($i); ?>">
                    <?php endfor; ?>
                </div>
                <p class="small text-shop-faint mb-4">Resend in <span id="otpTimer">00:30</span></p>
                <a href="<?php echo e(route('shop.account')); ?>" class="btn btn-shop-primary w-100 rounded-pill py-3 fw-semibold">Verify</a>
            </div>
        </div>

        <p class="text-center small text-shop-faint mt-4 mb-0">
            By continuing you accept our <a href="#" class="text-shop-muted">Terms</a> &amp; <a href="#" class="text-shop-muted">Privacy</a>.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.storefront', ['hideFooter' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\auth.blade.php ENDPATH**/ ?>