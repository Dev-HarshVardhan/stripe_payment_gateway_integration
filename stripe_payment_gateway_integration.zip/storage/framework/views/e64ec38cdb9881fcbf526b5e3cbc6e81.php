

<?php $__env->startSection('title', 'Browse'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('store.partials.header-category', ['navActive' => $navActive], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb mb-0 small">
            <li class="breadcrumb-item"><a href="<?php echo e(route('shop.home')); ?>" class="text-decoration-none text-shop-muted">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Snacks &amp; drinks</li>
        </ol>
    </nav>

    <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4">
        <div>
            <h1 class="shop-section-title h4 mb-1">Snacks &amp; drinks</h1>
            <p class="text-shop-muted small mb-0">128 products</p>
        </div>
        <div class="d-flex flex-wrap align-items-center gap-2">
            <button class="btn btn-shop-outline btn-sm d-lg-none rounded-pill" type="button" data-bs-toggle="offcanvas" data-bs-target="#qcFilters" aria-controls="qcFilters">
                <i class="bi bi-sliders me-1"></i> Filters
            </button>
            <div class="dropdown">
                <button class="btn btn-sm rounded-pill border-0 bg-body-secondary text-body px-3 dropdown-toggle" type="button" data-bs-toggle="dropdown">Sort</button>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-4">
                    <li><a class="dropdown-item rounded-3 active" href="#">Relevance</a></li>
                    <li><a class="dropdown-item rounded-3" href="#">Price ↑</a></li>
                    <li><a class="dropdown-item rounded-3" href="#">Price ↓</a></li>
                    <li><a class="dropdown-item rounded-3" href="#">Discount</a></li>
                </ul>
            </div>
            <div class="btn-group btn-group-sm" role="group" aria-label="View">
                <button type="button" class="btn btn-sm rounded-start-pill border-0 bg-body-secondary active" id="qcViewGrid"><i class="bi bi-grid-3x3-gap"></i></button>
                <button type="button" class="btn btn-sm rounded-end-pill border-0 bg-body-secondary" id="qcViewList"><i class="bi bi-list-ul"></i></button>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <aside class="col-lg-3 d-none d-lg-block shop-filter-sidebar">
            <div class="card border-0 p-4" style="box-shadow: var(--shop-shadow); border-radius: var(--shop-radius-lg) !important">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2 class="h6 shop-section-title mb-0">Filters</h2>
                    <button type="button" class="btn btn-link btn-sm p-0 text-shop-muted">Reset</button>
                </div>
                <?php echo $__env->make('store.partials.filter-panel', ['idSuffix' => 'D'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="d-grid gap-2 mt-4 pt-3 border-top" style="border-color: var(--shop-border) !important">
                    <button type="button" class="btn btn-shop-primary rounded-pill">Apply</button>
                </div>
            </div>
        </aside>

        <div class="col-lg-9">
            <div class="row row-cols-2 row-cols-md-3 row-cols-xl-4 g-3" id="qcProductGrid">
                <?php $__currentLoopData = [['c1', 'CrunchCo', 'Masala chips 150g', '40', '50', '20% OFF', '4.4', '520'], ['c2', 'PureJuice', 'Orange juice 1L', '99', '110', null, '4.6', '210'], ['c3', 'SnackBar', 'Protein bar 50g', '60', '65', null, '4.1', '88'], ['c4', 'FizzUp', 'Sparkling water 500ml', '35', '40', null, '4.0', '64']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <article class="qc-card-product d-flex flex-column h-100">
                            <div class="position-relative">
                                <a href="<?php echo e(route('shop.product')); ?>" class="d-block text-decoration-none">
                                    <div class="qc-img-wrap">
                                        <img src="https://picsum.photos/seed/<?php echo e($p[0]); ?>/400/400" alt="" loading="lazy">
                                        <?php if(! empty($p[5])): ?>
                                            <span class="position-absolute top-0 start-0 m-2 qc-badge-discount"><?php echo e($p[5]); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </a>
                                <button type="button" class="shop-wishlist" aria-label="Wishlist"><i class="bi bi-heart"></i></button>
                            </div>
                            <div class="card-body p-3 d-flex flex-column flex-grow-1">
                                <div class="small text-truncate text-shop-faint mb-1"><?php echo e($p[1]); ?></div>
                                <a href="<?php echo e(route('shop.product')); ?>" class="fw-semibold text-body text-truncate mb-1 text-decoration-none" style="font-size: 0.9rem"><?php echo e($p[2]); ?></a>
                                <div class="qc-rating mb-2"><i class="bi bi-star-fill"></i> <?php echo e($p[6]); ?> <span class="text-shop-faint">(<?php echo e($p[7]); ?>)</span></div>
                                <div class="mt-auto d-flex justify-content-between align-items-end">
                                    <div>
                                        <div class="qc-price-current">₹<?php echo e($p[3]); ?></div>
                                        <div class="qc-price-mrp">₹<?php echo e($p[4]); ?></div>
                                    </div>
                                    <button type="button" class="btn btn-shop-primary btn-icon-add rounded-3"><i class="bi bi-plus-lg"></i></button>
                                </div>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="d-flex justify-content-center mt-5">
                <button type="button" class="btn btn-sm rounded-pill px-4 border-0 bg-body-secondary">Load more</button>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-start" tabindex="-1" id="qcFilters" aria-labelledby="qcFiltersLabel">
        <div class="offcanvas-header border-bottom">
            <h2 class="offcanvas-title h5 mb-0 shop-section-title" id="qcFiltersLabel">Filters</h2>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column">
            <?php echo $__env->make('store.partials.filter-panel', ['idSuffix' => 'M'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="d-grid gap-2 mt-auto pt-3 border-top">
                <button type="button" class="btn btn-shop-primary rounded-pill" data-bs-dismiss="offcanvas">Apply</button>
                <button type="button" class="btn btn-sm text-shop-muted">Clear all</button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('fab'); ?>
    <a href="<?php echo e(route('shop.cart')); ?>" class="btn btn-shop-primary shop-fab d-inline-flex align-items-center gap-2 text-decoration-none shadow">
        <i class="bi bi-bag fs-5"></i>
        <span class="fw-semibold">₹428</span>
        <span class="badge rounded-pill bg-white text-dark border" style="font-size: 0.7rem">3</span>
    </a>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\category.blade.php ENDPATH**/ ?>