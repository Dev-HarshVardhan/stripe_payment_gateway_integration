<html>
<head>
</head>
<body>
<h1>Feed Page (Cached Data)</h1>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="border:1px solid #ccc; margin:10px;">
        <h3><?php echo e($post->title); ?></h3>
        <p><?php echo e($post->content); ?></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\feed.blade.php ENDPATH**/ ?>