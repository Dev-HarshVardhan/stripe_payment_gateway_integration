<header class="shop-shell sticky-top">
    <?php echo $__env->make('store.partials.topbar', ['searchPlaceholder' => 'Search orders, products…'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</header>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\partials\header-profile.blade.php ENDPATH**/ ?>