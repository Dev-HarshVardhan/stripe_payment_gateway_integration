

<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('store.partials.header-minimal', ['title' => 'Checkout', 'backUrl' => route('shop.cart')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_class', 'container py-3 pb-5'); ?>

<?php $__env->startSection('content'); ?>
    <ol class="list-unstyled d-flex flex-wrap gap-2 small text-shop-muted mb-4">
        <li class="badge rounded-pill bg-success-subtle text-success">1. Address</li>
        <li>→</li>
        <li class="badge rounded-pill bg-body-secondary">2. Slot</li>
        <li>→</li>
        <li class="badge rounded-pill bg-body-secondary">3. Pay</li>
    </ol>

    <section class="mb-4">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 shop-section-title mb-0">Delivery address</h2>
            <button type="button" class="btn btn-link btn-sm p-0 fw-medium" style="color: var(--shop-primary)" data-bs-toggle="modal" data-bs-target="#shopNewAddressModal">Add new</button>
        </div>
        <div class="list-group">
            <label class="list-group-item d-flex gap-3 align-items-start">
                <input class="form-check-input flex-shrink-0 mt-1" type="radio" name="addr" checked>
                <div>
                    <div class="fw-semibold">Home</div>
                    <div class="small text-shop-muted">12th Main, Indiranagar, Bengaluru — 560038</div>
                    <span class="badge bg-secondary-subtle text-secondary mt-1">Default</span>
                </div>
            </label>
            <label class="list-group-item d-flex gap-3 align-items-start">
                <input class="form-check-input flex-shrink-0 mt-1" type="radio" name="addr">
                <div>
                    <div class="fw-semibold">Office</div>
                    <div class="small text-shop-muted">100 Feet Road, Bengaluru — 560071</div>
                </div>
            </label>
        </div>
    </section>

    <section class="mb-4">
        <h2 class="h5 shop-section-title mb-3">Delivery slot</h2>
        <div class="btn-group flex-wrap mb-2" role="group" aria-label="Day">
            <input type="radio" class="btn-check" name="day" id="d1" autocomplete="off" checked>
            <label class="btn btn-outline-secondary btn-sm" for="d1">Today</label>
            <input type="radio" class="btn-check" name="day" id="d2" autocomplete="off">
            <label class="btn btn-outline-secondary btn-sm" for="d2">Tomorrow</label>
        </div>
        <div class="row g-2">
            <div class="col-6 col-md-4">
                <input type="radio" class="btn-check" name="slot" id="s1" autocomplete="off" checked>
                <label class="btn btn-outline-success w-100 py-3" for="s1">
                    <span class="fw-semibold d-block">12:00 – 12:30</span>
                    <span class="small text-success">Fastest</span>
                </label>
            </div>
            <div class="col-6 col-md-4">
                <input type="radio" class="btn-check" name="slot" id="s2" autocomplete="off">
                <label class="btn btn-outline-secondary w-100 py-3" for="s2">
                    <span class="fw-semibold d-block">12:30 – 1:00</span>
                </label>
            </div>
            <div class="col-6 col-md-4">
                <input type="radio" class="btn-check" name="slot" id="s3" autocomplete="off">
                <label class="btn btn-outline-secondary w-100 py-3" for="s3">
                    <span class="fw-semibold d-block">1:00 – 1:30</span>
                </label>
            </div>
        </div>
    </section>

    <section class="mb-4">
        <h2 class="h5 shop-section-title mb-3">Payment</h2>
        <div class="list-group list-group-flush rounded-4 border overflow-hidden" style="border-color: var(--shop-border) !important">
            <label class="list-group-item d-flex align-items-center gap-3 border-0 py-3">
                <input class="form-check-input flex-shrink-0" type="radio" name="pay" checked>
                <i class="bi bi-phone fs-4 text-shop-muted"></i>
                <div class="flex-grow-1">
                    <div class="fw-semibold">UPI</div>
                    <div class="small text-shop-muted">Google Pay, PhonePe, Paytm</div>
                </div>
            </label>
            <label class="list-group-item d-flex align-items-center gap-3 border-0 py-3">
                <input class="form-check-input flex-shrink-0" type="radio" name="pay">
                <i class="bi bi-credit-card fs-4 text-shop-muted"></i>
                <div>
                    <div class="fw-semibold">Card</div>
                    <div class="small text-shop-muted">Visa, Mastercard, RuPay</div>
                </div>
            </label>
            <label class="list-group-item d-flex align-items-center gap-3 border-0 py-3">
                <input class="form-check-input flex-shrink-0" type="radio" name="pay">
                <i class="bi bi-cash-coin fs-4 text-shop-muted"></i>
                <div>
                    <div class="fw-semibold">Cash on delivery</div>
                    <div class="small text-shop-muted">Pay when you receive</div>
                </div>
            </label>
        </div>
    </section>

    <div class="accordion mb-5" id="orderSummary">
        <div class="accordion-item border-0 rounded-4 overflow-hidden" style="box-shadow: var(--shop-shadow)">
            <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#summaryCollapse">
                    Order summary · ₹428 · 3 items
                </button>
            </h2>
            <div id="summaryCollapse" class="accordion-collapse collapse show" data-bs-parent="#orderSummary">
                <div class="accordion-body small">
                    <div class="d-flex justify-content-between mb-1"><span>Milk ×2</span><span>₹112</span></div>
                    <div class="d-flex justify-content-between mb-1"><span>Chips ×1</span><span>₹40</span></div>
                    <div class="d-flex justify-content-between"><span>Bananas ×2</span><span>₹84</span></div>
                    <hr>
                    <a href="<?php echo e(route('shop.cart')); ?>" class="small fw-medium" style="color: var(--shop-primary)">Edit cart</a>
                </div>
            </div>
        </div>
    </div>

    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="shopCheckoutToast" class="toast align-items-center text-bg-dark border-0 rounded-4" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body"><i class="bi bi-check-lg me-2"></i> Slot reserved for 5 minutes (demo).</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    </div>

    <div class="modal fade" id="shopNewAddressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-4 shadow" style="box-shadow: var(--shop-shadow-hover) !important">
                <div class="modal-header border-0 pb-0">
                    <h3 class="modal-title shop-section-title h5">New address</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pt-2">
                    <div class="mb-3">
                        <label class="form-label small text-shop-muted">Label</label>
                        <input type="text" class="form-control rounded-3 border-0 bg-body-secondary" placeholder="Home, Office…">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-shop-muted">Flat / street</label>
                        <input type="text" class="form-control rounded-3 border-0 bg-body-secondary">
                    </div>
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label small text-shop-muted">PIN</label>
                            <input type="text" class="form-control rounded-3 border-0 bg-body-secondary" placeholder="560038">
                        </div>
                        <div class="col-6">
                            <label class="form-label small text-shop-muted">City</label>
                            <input type="text" class="form-control rounded-3 border-0 bg-body-secondary" value="Bengaluru">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-shop-primary rounded-pill px-4" data-bs-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="qcPlaceOrderModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-body text-center py-5 px-4">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 64px; height: 64px; background: var(--shop-primary-soft); color: var(--shop-primary)">
                        <i class="bi bi-check-lg fs-3"></i>
                    </div>
                    <h3 class="h5 shop-section-title">Order placed</h3>
                    <p class="text-shop-muted small mb-4">Demo checkout — no payment processed.</p>
                    <a href="<?php echo e(route('shop.order')); ?>" class="btn btn-shop-primary rounded-pill px-4">Track order</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('fab'); ?>
    <div class="qc-sticky-bar">
        <div class="container">
            <button type="button" class="btn btn-shop-primary btn-lg w-100 rounded-pill py-3" data-bs-toggle="modal" data-bs-target="#qcPlaceOrderModal">Place order · ₹428</button>
        </div>
    </div>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.storefront', ['hideFooter' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\checkout.blade.php ENDPATH**/ ?>