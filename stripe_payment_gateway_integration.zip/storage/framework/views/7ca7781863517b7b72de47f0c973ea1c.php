<h1>Create Post</h1>

<form method="POST" action="/store-post">
    <?php echo csrf_field(); ?>
    <input type="text" name="title" placeholder="Title">
    <br><br>
    <textarea name="content" placeholder="Content"></textarea>
    <br><br>
    <button type="submit">Submit</button>
</form><?php /**PATH C:\xampp\htdocs\queue-test\resources\views\create-post.blade.php ENDPATH**/ ?>