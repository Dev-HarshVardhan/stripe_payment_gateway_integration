<?php
    $a = $navActive ?? '';
?>
<div class="w-100 d-flex gap-1 gap-md-3 overflow-auto pb-1 small fw-medium" style="scrollbar-width: thin">
    <a class="nav-link px-2 py-1 text-nowrap <?php echo e($a === 'home' ? 'rounded-pill bg-success bg-opacity-10 text-success' : 'text-qc-secondary'); ?>" href="<?php echo e(route('shop.home')); ?>">Home</a>
    <a class="nav-link px-2 py-1 text-nowrap <?php echo e($a === 'category' ? 'rounded-pill bg-success bg-opacity-10 text-success' : 'text-qc-secondary'); ?>" href="<?php echo e(route('shop.category')); ?>">Categories</a>
    <a class="nav-link px-2 py-1 text-nowrap <?php echo e($a === 'orders' ? 'rounded-pill bg-success bg-opacity-10 text-success' : 'text-qc-secondary'); ?>" href="<?php echo e(route('shop.account')); ?>">Orders</a>
    <a class="nav-link px-2 py-1 text-nowrap <?php echo e($a === 'search' ? 'rounded-pill bg-success bg-opacity-10 text-success' : 'text-qc-secondary'); ?>" href="<?php echo e(route('shop.search')); ?>">Search</a>
    <a class="nav-link px-2 py-1 text-nowrap text-qc-secondary d-md-none" href="<?php echo e(route('shop.login')); ?>">Login</a>
</div>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\partials\nav-strip.blade.php ENDPATH**/ ?>