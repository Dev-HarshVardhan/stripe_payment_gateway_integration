<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Checkout — Stripe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <h1 class="h4 mb-3">Pay with card</h1>
                    <p class="text-muted small mb-4">Payment Intents + Stripe.js (Payment Element). Use test cards in Stripe Dashboard.</p>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <div id="alert-box" class="alert d-none" role="alert"></div>

                    <form id="pricing-form" class="mb-3">
                        <div class="mb-3">
                            <label for="amount_dollars" class="form-label">Amount (major units, e.g. USD)</label>
                            <input type="number" step="0.01" min="0.50" class="form-control" id="amount_dollars"
                                   name="amount_dollars" value="<?php echo e($defaultAmountDollars); ?>" required>
                            <div class="form-text">Minimum 0.50 in most currencies; converted to smallest currency unit for Stripe.</div>
                        </div>
                        <div class="mb-3">
                            <label for="currency" class="form-label">Currency</label>
                            <select class="form-select" id="currency" name="currency">
                                <?php $__currentLoopData = ['usd', 'eur', 'gbp', 'inr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cur); ?>" <?php if($defaultCurrency === $cur): echo 'selected'; endif; ?>><?php echo e(strtoupper($cur)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="product_id" class="form-label">Product ID (optional)</label>
                            <input type="number" min="1" class="form-control" id="product_id" name="product_id"
                                   value="<?php echo e($defaultProductId); ?>" placeholder="e.g. 101">
                        </div>
                        <div class="mb-3">
                            <label for="product_name" class="form-label">Product name (Stripe Checkout only)</label>
                            <input type="text" class="form-control" id="product_name" name="product_name" maxlength="120"
                                   value="Demo product" placeholder="Shown on hosted Checkout page">
                        </div>
                    </form>

                    <button type="button" class="btn btn-primary w-100 mb-2" id="prepare-pay">
                        Pay now
                    </button>
                    <button type="button" class="btn btn-outline-secondary w-100 mb-4" id="hosted-checkout">
                        Pay with Stripe Checkout (hosted page)
                    </button>

                    <form id="payment-form" class="d-none">
                        <div id="payment-element" class="mb-3"></div>
                        <button type="submit" class="btn btn-success w-100" id="submit-payment" disabled>
                            Submit payment
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://js.stripe.com/v3/"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
<script>
    const stripePublicKey = <?php echo json_encode($stripeKey, 15, 512) ?>;
    const stripe = Stripe(stripePublicKey);
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    const alertBox = document.getElementById('alert-box');

    function showAlert(message, kind) {
        alertBox.textContent = message;
        alertBox.className = 'alert alert-' + (kind || 'danger');
        alertBox.classList.remove('d-none');
    }

    function hideAlert() {
        alertBox.classList.add('d-none');
    }

    function dollarsToStripeAmount(dollars, currency) {
        const zeroDecimal = ['bif', 'clp', 'djf', 'gnf', 'jpy', 'kmf', 'krw', 'mga', 'pyg', 'rwf', 'ugx', 'vnd', 'vuv', 'xaf', 'xof', 'xpf'];
        const c = currency.toLowerCase();
        const factor = zeroDecimal.includes(c) ? 1 : 100;
        return Math.round(parseFloat(dollars) * factor);
    }

    let elements;
    let paymentElement;

    document.getElementById('prepare-pay').addEventListener('click', async () => {
        hideAlert();
        const currency = document.getElementById('currency').value;
        const amountMajor = document.getElementById('amount_dollars').value;
        const amount = dollarsToStripeAmount(amountMajor, currency);
        const productIdRaw = document.getElementById('product_id').value;
        const product_id = productIdRaw ? parseInt(productIdRaw, 10) : null;

        const body = { amount, currency, product_id };
        let res;
        try {
            res = await fetch(<?php echo json_encode(route('payment.intent'), 15, 512) ?>, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                },
                body: JSON.stringify(body),
            });
        } catch (e) {
            showAlert('Network error. Please try again.');
            return;
        }

        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
            showAlert(data.message || 'Could not create payment.');
            return;
        }

        const clientSecret = data.clientSecret;
        elements = stripe.elements({ clientSecret });
        if (paymentElement) {
            paymentElement.unmount();
        }
        paymentElement = elements.create('payment');
        paymentElement.mount('#payment-element');

        document.getElementById('payment-form').classList.remove('d-none');
        document.getElementById('submit-payment').disabled = false;
    });

    document.getElementById('hosted-checkout').addEventListener('click', async () => {
        hideAlert();
        const currency = document.getElementById('currency').value;
        const amountMajor = document.getElementById('amount_dollars').value;
        const amount = dollarsToStripeAmount(amountMajor, currency);
        const productIdRaw = document.getElementById('product_id').value;
        const product_id = productIdRaw ? parseInt(productIdRaw, 10) : null;
        const product_name = document.getElementById('product_name').value || 'Order';

        let res;
        try {
            res = await fetch(<?php echo json_encode(route('payment.checkout.session'), 15, 512) ?>, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                },
                body: JSON.stringify({ amount, currency, product_id, product_name }),
            });
        } catch (e) {
            showAlert('Network error. Please try again.');
            return;
        }
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
            showAlert(data.message || 'Could not start Checkout.');
            return;
        }
        window.location.href = data.url;
    });

    document.getElementById('payment-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        hideAlert();
        document.getElementById('submit-payment').disabled = true;

        const { error, paymentIntent } = await stripe.confirmPayment({
            elements,
            confirmParams: {
                return_url: <?php echo json_encode(url('/payment/success'), 15, 512) ?>,
            },
            redirect: 'if_required',
        });

        if (error) {
            showAlert(error.message || 'Payment failed.');
            document.getElementById('submit-payment').disabled = false;
            return;
        }

        if (paymentIntent && paymentIntent.status === 'succeeded') {
            let confirmRes;
            try {
                confirmRes = await fetch(<?php echo json_encode(route('payment.confirm'), 15, 512) ?>, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken,
                    },
                    body: JSON.stringify({ payment_intent_id: paymentIntent.id }),
                });
            } catch (err) {
                showAlert('Could not confirm payment on server; check your dashboard.');
                document.getElementById('submit-payment').disabled = false;
                return;
            }
            const confirmData = await confirmRes.json().catch(() => ({}));
            if (confirmRes.ok && confirmData.redirect_url) {
                window.location.href = confirmData.redirect_url;
                return;
            }
            window.location.href = <?php echo json_encode(url('/payment/success'), 15, 512) ?> + '?payment_intent=' + encodeURIComponent(paymentIntent.id);
            return;
        }

        showAlert('Unexpected payment state. If you were redirected for authentication, complete it in the new page.');
        document.getElementById('submit-payment').disabled = false;
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\payment\checkout.blade.php ENDPATH**/ ?>