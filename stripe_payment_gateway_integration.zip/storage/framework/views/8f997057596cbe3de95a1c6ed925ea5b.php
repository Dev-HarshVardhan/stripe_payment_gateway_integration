<footer class="qc-footer mt-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="shop-display fw-semibold mb-2" style="font-size: 1.15rem; color: var(--shop-ink)">Shop</div>
                <p class="mb-0 text-shop-muted small">Premium quick-commerce UI — fast, minimal, focused.</p>
            </div>
            <div class="col-6 col-md-4">
                <div class="fw-semibold small mb-2 text-uppercase text-shop-faint" style="letter-spacing: 0.06em">Browse</div>
                <ul class="list-unstyled mb-0 small">
                    <li class="mb-2"><a href="<?php echo e(route('shop.category')); ?>" class="text-shop-muted text-decoration-none">Categories</a></li>
                    <li><a href="<?php echo e(route('shop.search')); ?>" class="text-shop-muted text-decoration-none">Search</a></li>
                </ul>
            </div>
            <div class="col-6 col-md-4">
                <div class="fw-semibold small mb-2 text-uppercase text-shop-faint" style="letter-spacing: 0.06em">Support</div>
                <ul class="list-unstyled mb-0 small">
                    <li class="mb-2"><a href="<?php echo e(route('shop.login')); ?>" class="text-shop-muted text-decoration-none">Login</a></li>
                    <li><a href="<?php echo e(route('shop.order')); ?>" class="text-shop-muted text-decoration-none">Track order</a></li>
                </ul>
            </div>
        </div>
        <hr class="my-4 opacity-25">
        <p class="mb-0 small text-center text-shop-faint">© <?php echo e(date('Y')); ?> Shop</p>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\partials\footer.blade.php ENDPATH**/ ?>