<?php
    $searchPlaceholder = $searchPlaceholder ?? 'Search milk, snacks, essentials…';
?>

<div class="shop-glass border-bottom bg-white" style="border-color: var(--shop-border) !important">
    <div class="container py-2 py-md-2">
        <div class="d-flex align-items-center gap-2 gap-md-3 flex-nowrap">
            <a href="<?php echo e(route('shop.home')); ?>" class="shop-brand-icon flex-shrink-0 text-decoration-none rounded-3 d-inline-flex align-items-center justify-content-center" aria-label="Shop home">
                <i class="bi bi-bag-fill" style="font-size: 1.35rem; color: var(--shop-primary)"></i>
            </a>
            <button type="button" class="shop-loc-btn flex-shrink-0 d-inline-flex">
                <i class="bi bi-geo-alt" style="color: var(--shop-primary)"></i>
                <span class="text-truncate" style="max-width: 7rem">
                    <span class="text-shop-faint fw-normal">Deliver to</span>
                    <strong>Indiranagar</strong>
                </span>
                <i class="bi bi-chevron-down small text-shop-faint"></i>
            </button>
            <div class="shop-search-wrap position-relative flex-grow-1 min-w-0">
                <i class="bi bi-search position-absolute"></i>
                <a href="<?php echo e(route('shop.search')); ?>" class="stretched-link" aria-label="Search"></a>
                <input type="search" class="form-control shadow-none shop-search-input border-0" placeholder="<?php echo e($searchPlaceholder); ?>" readonly>
            </div>
            <div class="d-flex align-items-center gap-0 flex-shrink-0">
                <button type="button" class="btn btn-link p-2 rounded-circle text-shop-muted d-none d-lg-inline-flex" id="shopThemeToggle" aria-label="Theme">
                    <i class="bi bi-moon fs-5"></i>
                </button>
                <a class="btn btn-link p-2 rounded-circle text-body" href="<?php echo e(route('shop.account')); ?>" aria-label="Account">
                    <i class="bi bi-person fs-4"></i>
                </a>
                <a class="btn btn-link p-2 rounded-circle text-body position-relative" href="<?php echo e(route('shop.cart')); ?>" aria-label="Cart">
                    <i class="bi bi-bag fs-5"></i>
                    <span class="position-absolute top-0 end-0 translate-middle badge rounded-pill bg-danger border border-white" style="font-size: 0.6rem; padding: 0.2em 0.45em">3</span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\partials\topbar.blade.php ENDPATH**/ ?>