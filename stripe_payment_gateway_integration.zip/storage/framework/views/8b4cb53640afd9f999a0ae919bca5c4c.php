<header class="shop-shell sticky-top shop-glass border-bottom">
    <div class="container py-2 d-flex align-items-center gap-2">
        <a class="btn btn-link text-shop-muted px-0 rounded-circle" href="<?php echo e(route('shop.category')); ?>" aria-label="Back"><i class="bi bi-arrow-left fs-5"></i></a>
        <a class="navbar-brand shop-display fw-semibold mb-0 me-auto text-decoration-none" href="<?php echo e(route('shop.home')); ?>" style="color: var(--shop-ink); font-size: 1.15rem">Shop</a>
        <button type="button" class="btn btn-link p-2 rounded-circle text-shop-muted" id="shopThemeToggle" aria-label="Toggle dark mode">
            <i class="bi bi-moon-stars fs-5"></i>
        </button>
        <a class="btn btn-shop-primary rounded-pill position-relative px-3 py-2" href="<?php echo e(route('shop.cart')); ?>">
            <i class="bi bi-bag"></i>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger border border-white" style="font-size: 0.65rem; padding: 0.25em 0.45em">3</span>
        </a>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\partials\header-product.blade.php ENDPATH**/ ?>