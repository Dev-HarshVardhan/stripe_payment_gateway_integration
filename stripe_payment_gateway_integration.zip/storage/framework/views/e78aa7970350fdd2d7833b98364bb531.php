<header class="shop-shell sticky-top shop-glass border-bottom">
    <div class="container py-3">
        <div class="d-flex align-items-center gap-2 mb-3">
            <a class="btn btn-link text-shop-muted px-0 rounded-circle" href="<?php echo e(route('shop.home')); ?>" aria-label="Back"><i class="bi bi-arrow-left fs-5"></i></a>
            <div class="shop-search-wrap position-relative flex-grow-1">
                <i class="bi bi-search position-absolute" style="left: 1rem; top: 50%; transform: translateY(-50%); color: var(--shop-muted-2)"></i>
                <input
                    type="search"
                    class="form-control shadow-none"
                    id="shopSearchInput"
                    placeholder="Search…"
                    value="organic milk"
                    autofocus
                    autocomplete="off"
                    aria-controls="shopSearchSuggest"
                >
            </div>
            <button type="button" class="btn btn-link p-2 rounded-circle text-shop-muted" id="shopThemeToggle" aria-label="Toggle dark mode">
                <i class="bi bi-moon-stars fs-5"></i>
            </button>
        </div>
        <div class="position-relative">
            <div class="qc-search-dropdown position-absolute mt-0 bg-body border rounded-4 shadow-sm py-2 w-100" id="shopSearchSuggest" role="listbox" style="border-color: var(--shop-border) !important">
                <div class="px-3 py-2 small text-shop-faint text-uppercase fw-semibold" style="font-size: 0.65rem; letter-spacing: 0.06em">Suggestions</div>
                <button type="button" class="dropdown-item py-2 rounded-3 mx-2">Organic <mark class="px-0 bg-transparent text-decoration-underline">milk</mark> 1L</button>
                <button type="button" class="dropdown-item py-2 rounded-3 mx-2">Category: Dairy</button>
                <hr class="my-2 opacity-25">
                <div class="px-3 py-2 small text-shop-faint text-uppercase fw-semibold" style="font-size: 0.65rem">Recent</div>
                <div class="px-3 pb-2 d-flex flex-wrap gap-2">
                    <span class="shop-chip">banana</span>
                    <span class="shop-chip">chips</span>
                </div>
                <div class="px-3 py-2 small text-shop-faint text-uppercase fw-semibold" style="font-size: 0.65rem">Trending</div>
                <div class="px-3 pb-2 d-flex flex-wrap gap-2">
                    <a href="<?php echo e(route('shop.category')); ?>" class="shop-chip">Cold drinks</a>
                    <a href="<?php echo e(route('shop.category')); ?>" class="shop-chip">Bread</a>
                    <a href="<?php echo e(route('shop.category')); ?>" class="shop-chip">Eggs</a>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\queue-test\resources\views\store\partials\header-search.blade.php ENDPATH**/ ?>